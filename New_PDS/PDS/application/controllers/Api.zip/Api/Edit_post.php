<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Edit_post extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$user_id = $this->post('user_id');
		$post_id = $this->post('post_id');
		$user_title = $this->post('user_title');
	     
		
		 
    if(!empty($user_title))
    {
            $timeLineDataEdit = array(
    		      'kon_title'=>$user_title,
			 );
			 
			 $this->db->update('timeLine_posts',$timeLineDataEdit,array('id'=>$post_id,'user_id'=>$user_id));
	   
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $timeLineDataEdit
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
