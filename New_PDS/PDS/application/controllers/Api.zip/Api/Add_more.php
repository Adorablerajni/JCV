<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_more extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
	    $poll_id = $this->post('poll_id');
		$user_id = $this->post('user_id');
		$user_choice1 = $this->post('user_choice1');
		$user_choice2 = $this->post('user_choice2');
		
    if(!empty($user_id))
    {
	    $add_more_choice_poll = array(
    		'kon_choice3'=>$user_choice1,
    		'kon_choice4'=>$user_choice2,
    		);
	     
		$this->db->update('poll_list',$add_more_choice_poll,array('id'=>$poll_id,'user_id'=>$user_id));
	     
	      
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_more_choice_poll
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
