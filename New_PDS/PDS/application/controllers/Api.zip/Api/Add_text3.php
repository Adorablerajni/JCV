<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_text3 extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$user_id = $this->post('user_id');
		$user_textarea = $this->post('user_textarea');
        $user_level = $this->post('user_level');
		$user_share = $this->post('user_share');
		$user_private_content = $this->post('user_private_content');
        $user_tags = $this->post('user_tags');
        $user_language = $this->post('user_language');
		$user_restrict_to = $this->post('user_restrict_to');
        $user_duration = $this->post('user_duration');
		$user_content_type = $this->post('user_content_type');
        $user_pricing = $this->post('user_pricing');
	     
    if(!empty($user_textarea))
    {
	    $add_textarea = array(
    		'user_id'=> $user_id,
    		'kon_textarea'=>$user_textarea,
    		'kon_share'=>$user_share,
    		'kon_level'=>$user_level,
    		'kon_private_content'=> $user_private_content,
    		'kon_tag'=>$user_tags,
    		'kon_language'=>$user_language,
    		'kon_restrict_to'=>$user_restrict_to,
    		'kon_duration'=>$user_duration,
    		'kon_content_type'=>$user_content_type,
    		'kon_pricing'=>$user_pricing,
    		);
	
        $this->db->insert('add_text',$add_textarea);
		
		$text_last_id =$this->db->insert_id();
			
            $timeLineData = array(
			      'text_id'=> $text_last_id,
			      'user_id'=> $user_id,
    		      'kon_textarea'=>$user_textarea,
    		      'kon_level'=>$user_level,
    		      'kon_share'=> $user_share,
    		      'kon_tag'=>$user_tags,
    		      'kon_language'=>$user_language,
    		      'kon_restrict_to'=>$user_restrict_to,
    		      'kon_duration'=>$user_duration,
    		      'kon_content_type'=>$user_content_type,
    		      'kon_pricing'=>$user_pricing,
    		      'kon_post_type'=>'Text',
			 );
            $this->db->insert('timeLine_posts',$timeLineData);
			
	      
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_textarea
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
