<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class View_user extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_get()
{
        $u_id = $this->get('u_id');
		
	if(!empty($_GET)) 
		{
		$query = $this->db->query("SELECT `id` as user_id, `kon_name`, `kon_email`, `kon_mobile`, `kon_dob`, `kon_gender`, `kon_address`, `kon_city`, `kon_state`, `kon_country`, `kon_profile_pic`, `kon_bio`, `kon_unq_id`, `kon_device_id`, `kon_token`, `kon_aadhar`, `kon_pan`, `account_status`, `kon_status` from konnect_users where id = '".$u_id."'");
            
            if ($query->num_rows() > 0)
            {
				//$userData = array();
                //$userData = $query->result_array();
               
               $userData = $query->result_array();
               $i=0;
               foreach($userData as $val){
                   
                   $unique_id_user = $val['kon_unq_id'];
                   
                   function encrypt_decrypt($action, $string) {
	//$string = "L3IyY1dnWi95elRWSTZSNTBhcm5WZz09";

    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = '3{`5+QjnDEYL$:q+Wy';
    $secret_iv = '4569821431478';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}
			 $encrypted_password = encrypt_decrypt('encrypt',$unique_id_user);
			 
                   $userData[$i] = array(
                                                        'user_id'=>$val['user_id'],
                        								'kon_name'=>$val['kon_name'],
                        								'kon_email'=>$val['kon_email'], 
                        								'kon_mobile'=>$val['kon_mobile'],
                        								'kon_dob'=>$val['kon_dob'],
                        								'kon_gender'=>$val['kon_gender'],
                        								'kon_address'=>$val['kon_address'],
                        								'kon_state'=>$val['kon_state'],
                        								'kon_country'=>$val['kon_country'],
                        								'kon_profile_pic'=>$val['kon_profile_pic'],
                        								'kon_bio'=>$val['kon_bio'],
                        								'kon_unq_id'=>$encrypted_password,
                        								'kon_device_id'=>$val['kon_device_id'],
                        								'kon_token'=>$val['kon_token'],
                        								'kon_aadhar'=>$val['kon_aadhar'],
                        								'kon_pan'=>$val['kon_pan'],
                        								'account_status'=>$val['account_status'],
                        								'kon_status'=>$val['kon_status']
                       );
                   $i++;
               }
               
			    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $userData
                ], REST_Controller::HTTP_OK);
            }
            else
			{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
            }
        }
		else
		{
        $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
       }
           
}
}
