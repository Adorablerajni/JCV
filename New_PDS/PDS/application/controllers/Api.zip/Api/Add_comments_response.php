<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_comments_response extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
	    $user_id = $this->post('user_id');
	    $timeline_id = $this->post('timeline_id');
		$comments = $this->post('comments');
		$commented_by_id = $this->post('commented_by_id');
		
		
    if(!empty($user_id) && !empty($timeline_id) && !empty($commented_by_id))
    {
	    $comment_response = array(
    		'post_user_id'=>$user_id,
    		'timeline_post_id'=>$timeline_id,
    		'comments'=>$comments,
    		'commented_by'=>$commented_by_id,
    		);
	     
		 $this->db->insert('timeline_post_comments',$comment_response);
		
	      $add_noti = array(
        		'notification_type'=> 'Post Comment',
        		'sender_id'=>$commented_by_id,
        		'receiver_id'=>$user_id,
        		'post_id'=>$timeline_id,
        		'status'=>'Commented',
        		);
		   $this->db->insert('notification_tbl',$add_noti);
	      
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $comment_response
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
