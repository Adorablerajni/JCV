<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class View_timeline_uplods extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_get()
{
        $user_id = $this->get('user_id');
		
	if(!empty($_GET)) 
		{
		$query = $this->db->query("SELECT `id`, `image`, `title`, `level`, `share`, `tag`, `private_content`, `user_id`, `language`, `restrict_to`, `duration`, `content_type`, `pricing` from upload_list where user_id = '".$user_id."'");
            
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
               
			    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $userData
                ], REST_Controller::HTTP_OK);
            }
            else
			{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
            }
        }
		else
		{
        $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
       }
           
}
}
