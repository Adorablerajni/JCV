<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_uploads extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$user_id = $this->post('user_id');
		$user_title = $this->post('user_title');
		$image_count = $this->post('image_count');
        $user_level = $this->post('user_level');
		$user_share = $this->post('user_share');
		$user_private_content = $this->post('user_private_content');
        $user_tags = $this->post('user_tags');
        $user_language = $this->post('user_language');
		$user_restrict_to = $this->post('user_restrict_to');
        $user_duration = $this->post('user_duration');
		$user_content_type = $this->post('user_content_type');
        $user_pricing = $this->post('user_pricing');
        
       
        // If file upload form submitted
        if(!empty($_FILES['image']['name'])){
            
            $filesCount = count($_FILES['image']['name']);
            for($i = 0; $i < $filesCount; $i++)
            {
                
                $imagename=date("d-m-Y")."-".time();
                
                $_FILES['file']['name']     = $_FILES['image']['name'][$i];
                $_FILES['file']['type']     = $_FILES['image']['type'][$i];
                $_FILES['file']['tmp_name'] = $_FILES['image']['tmp_name'][$i];
                $_FILES['file']['error']    = $_FILES['image']['error'][$i];
                $_FILES['file']['size']     = $_FILES['image']['size'][$i];

                $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
                	    
                if($ext ==='gif' || $ext ==='jpg' || $ext ==='png' || $ext ==='PNG' ||$ext ==='jpeg')
                {
                // File upload configuration
                $uploadPath = './upload/Timeline_image/';  //uploads/files/
                $config['upload_path'] = $uploadPath;
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size'] = "2048";
                $config['file_name'] = $imagename;
                
                // Load and initialize upload library
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                
                    // Upload file to server
                    if($this->upload->do_upload('file'))
                    {
                        
                        // Uploaded file data
                        $fileData = $this->upload->data();
                        $fileName = "Timeline_image/".$fileData['file_name']; //. '.' .$ext;  //$fileData['file_name'];
                    }
                
                }
				
             
           $unique_id = 'Img'.'_'.mt_rand(1000,9999);
		   
            $timeLineData = array(
			      'user_id'=> $user_id,
    		      'kon_image'=>$fileName,
    		      'kon_title'=>$user_title,
    		      'image_count'=>$image_count,
    		      'kon_level'=>$user_level,
    		      'kon_share'=> $user_share,
    		      'kon_private_content'=> $user_private_content,   
    		      'kon_tag'=>$user_tags,
    		      'kon_language'=>$user_language,
    		      'kon_restrict_to'=>$user_restrict_to,
    		      'kon_duration'=>$user_duration,
    		      'kon_content_type'=>$user_content_type,
    		      'kon_pricing'=>$user_pricing,
    		      'kon_post_type'=>'Image',
    		      'image_category'=>'TimeLine Image',
			 );
			 
            $this->db->insert('timeLine_posts',$timeLineData);
			
            $image_last_id =$this->db->insert_id();	
			     
    	    $add_image = array(
        		'post_id'=> $image_last_id,
        		'user_id'=> $user_id,
        		'image'=>$fileName,
        		'title'=>$user_title,
        		'level'=>$user_level,
        		'share'=> $user_share,
        		'private_content'=> $user_private_content,
        		'tag'=>$user_tags,
        		'language'=>$user_language,
        		'restrict_to'=>$user_restrict_to,
        		'duration'=>$user_duration,
        		'content_type'=>$user_content_type,
        		'pricing'=>$user_pricing,
        		); 
        		
            $this->db->insert('upload_list',$add_image);
    	    
          
            }
        }
        
        if(!empty($image_last_id) && (!empty($add_image) || !empty($user_title)))
        {
            
    	    $this->response([
                        'status' => TRUE,
                        'message' => 'Success'
    					//'data' => $add_image
                    ], REST_Controller::HTTP_OK);
                    
        }
        else
        {
            
            $this->response([
                        'status' => FALSE,
                        'message' => 'Failed!!!'
                    ], REST_Controller::HTTP_OK);
                    
        }

	/*
		 $imagename=date("d-m-Y")."-".time();
       
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            if($ext ==='gif' || $ext ==='jpg' || $ext ==='png' || $ext ==='PNG' ||$ext ==='jpeg')
            {
            $config = array(
            'upload_path'   => './upload/Timeline_image/',
            'allowed_types' => 'gif|jpg|png|jpeg',
            'max_size' => "2048", // Can be set to particular file size , here it is 2 MB(2048 Kb)
            'file_name'     =>$imagename //"criminal_images!".$imagename
            );        
            $this->load->library('upload');
            $this->upload->initialize($config);
                    
            if(!$this->upload->do_upload('image'))
            {
            $error = array('error' => $this->upload->display_errors());
            echo $this->upload->display_errors() ;
            die("image");
            }
            else
            {
            $imageDetailArray = $this->upload->data();
            $fileName = "Timeline_image/".$imagename. '.' .$ext; // $imageDetailArray['file_name'];
            }
            }
	
    if(!empty($user_title))
    {
	    $add_image = array(
    		'user_id'=> $user_id,
    		'image'=>$fileName,
    		'title'=>$user_title,
    		'level'=>$user_level,
    		'share'=> $user_share,
    		'private_content'=> $user_private_content,
    		'tag'=>$user_tags,
    		'language'=>$user_language,
    		'restrict_to'=>$user_restrict_to,
    		'duration'=>$user_duration,
    		'content_type'=>$user_content_type,
    		'pricing'=>$user_pricing,
    		);
	
        $this->db->insert('upload_list',$add_image);
	    
        $image_last_id =$this->db->insert_id();
			
            $timeLineData = array(
			      'image_id'=> $image_last_id,
			      'user_id'=> $user_id,
    		      'kon_image'=>$fileName,
    		      'kon_title'=>$user_title,
    		      'kon_level'=>$user_level,
    		      'kon_share'=> $user_share,
    		      'kon_private_content'=> $user_private_content,   
    		      'kon_tag'=>$user_tags,
    		      'kon_language'=>$user_language,
    		      'kon_restrict_to'=>$user_restrict_to,
    		      'kon_duration'=>$user_duration,
    		      'kon_content_type'=>$user_content_type,
    		      'kon_pricing'=>$user_pricing,
    		      'kon_post_type'=>'Image',
    		      'image_category'=>'TimeLine Image',
			 );
            $this->db->insert('timeLine_posts',$timeLineData);
			
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_image
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
    
    */
}
}
