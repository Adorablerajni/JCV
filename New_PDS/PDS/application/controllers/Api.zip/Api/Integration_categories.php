<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Integration_categories extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_get()
{
        
		$query = $this->db->query("SELECT * from integration_group where status ='1'");
            
            if ($query->num_rows() > 0)
            {
				
                $userData = $query->result_array();
               
			    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $userData
                ], REST_Controller::HTTP_OK);
            }
            else
			{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
            }
        
           
}
}
