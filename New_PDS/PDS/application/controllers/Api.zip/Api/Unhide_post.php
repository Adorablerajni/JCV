<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Unhide_post extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
    public function index_post()
	{
		$post_id = $this->post('post_id');
		$hidden_by = $this->post('hidden_by');
	
        if(!empty($post_id) && !empty($hidden_by))
        {

    		$query = $this->db->query("SELECT * from hide_list where status = 'Hide' AND post_id = '".$post_id."' and hidden_by = '".$hidden_by."'");
            
            if ($query->num_rows() > 0)
            {
                $userData['HidePost'] = $query->row_array();
                $this->db->where('id', $userData['HidePost']['id']);
                $this->db->delete('hide_list');
                
        	    $this->response([
                            'status' => TRUE,
                            'message' => 'Success',
                        ], REST_Controller::HTTP_OK);
                
            }
            else
            {
                
                $this->response([
                        'status' => FALSE,
                        'message' => 'Failed!!!'
                    ], REST_Controller::HTTP_OK);
                
            }
            
        }
        else
        {
                
            $this->response([
                'status' => FALSE,
                'message' => 'Required parameters are not available.'
            ], REST_Controller::HTTP_BAD_REQUEST);
            
        }
           
    }
}
