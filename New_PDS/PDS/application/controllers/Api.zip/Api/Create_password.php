<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Create_password extends REST_Controller 
{
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    /**
     * Get All Data from this method.
     *
     * @return Response
    */

public function index_post()
{
    
	$user_id = $this->post('user_id');  
	$pofile_type = $this->post('pofile_type');  
	$kon_access = $this->post('kon_access');  
	$new_pass = $this->post('new_pass');
		
	if(!empty($new_pass))
	{
		$create_pass = array(
    		                 'kon_pswrd'=>$new_pass,
    		                 'pofile_type' => $pofile_type,
    		                 'kon_access' => $kon_access,
    		                );
		
         $this->db->update('konnect_users',$create_pass,array('id'=>$user_id ));
		 
		 $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $create_pass
                ], REST_Controller::HTTP_OK);
    }
	else
	{
         $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
    }
}
     
	
}