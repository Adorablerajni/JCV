

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="jumbotron">
            <h1><?php echo e($user->name); ?></h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_store\resources\views\profiles\show.blade.php ENDPATH**/ ?>