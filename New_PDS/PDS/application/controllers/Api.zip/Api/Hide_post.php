<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Hide_post extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
    public function index_post()
    {
    	$post_id = $this->post('post_id');
    	$hidden_by = $this->post('hidden_by');
    	      
        if(!empty($post_id) && !empty($hidden_by))
        { 
        
            $status = 'Hide';
            
                $timeLineDataHide = array(
        		      'post_id'=>$post_id,
        		      'hidden_by'=>$hidden_by,
        		      'status'=>$status
    			 );
    			 
    		$this->db->insert('hide_list',$timeLineDataHide);
    		
    		$last_id = $this->db->insert_id();
    	   
    	    if($last_id != '')
    	    {
        	    $this->response([
                            'status' => TRUE,
                            'message' => 'Success'
        					//'data' => $timeLineDataHide
                        ], REST_Controller::HTTP_OK);
            }        
            else
            {
                $this->response([
                            'status' => FALSE,
                            'message' => 'Failed!!!'
                        ], REST_Controller::HTTP_OK);
            }      
                    
        }
		else
		{
            $this->response([
                'status' => FALSE,
                'message' => 'Required parameters are not available.'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}
