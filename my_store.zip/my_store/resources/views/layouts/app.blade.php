@include('layouts.includes.header')
@yield('content')
@include('layouts.includes.footer')