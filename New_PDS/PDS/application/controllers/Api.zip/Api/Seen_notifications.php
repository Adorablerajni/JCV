<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Seen_notifications extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_post()
{
        $seen_status = $this->post('seen_status');
		$user_id = $this->post('user_id');
		
	if(!empty($seen_status))
{
        $seen = array(
    		'seen_status'=> 'Seen',
    		
    		);
    		
         $this->db->update('notification_tbl',$seen,array('receiver_id'=>$user_id,'seen_status'=>'Unseen' ));
	      
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $seen
                ], REST_Controller::HTTP_OK);
                
            }
            else{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
           
    }
}
