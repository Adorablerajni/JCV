<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_like_response extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
	    $user_id = $this->post('user_id');
	    $timeline_id = $this->post('timeline_id');
		$liked_by_id = $this->post('liked_by_id');
		
		
    if(!empty($user_id) && !empty($timeline_id) && !empty($liked_by_id))
    {
		$status = 'Yes';
		
	    $like_response = array(
    		'post_user_id'=>$user_id,
    		'timeline_post_id'=>$timeline_id,
    		'like_status'=>$status,
    		'liked_by'=>$liked_by_id,
    		);
	     
		 $this->db->insert('timeline_post_likes',$like_response);
		
	     $add_noti = array(
        		'notification_type'=> 'Post Like',
        		'sender_id'=>$liked_by_id,
        		'receiver_id'=>$user_id,
        		'post_id'=>$timeline_id,
        		'status'=>'Liked',
        		);
		   $this->db->insert('notification_tbl',$add_noti);
	      
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $like_response
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
