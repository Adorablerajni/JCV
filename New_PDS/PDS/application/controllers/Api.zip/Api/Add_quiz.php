<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_quiz extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$user_id = $this->post('user_id');
		$user_question = $this->post('user_question');
		$user_answer1 = $this->post('user_answer1');
		$user_answer2 = $this->post('user_answer2');
		$user_answer3 = $this->post('user_answer3');
		$user_answer4 = $this->post('user_answer4');
		$user_correct_answer = $this->post('user_correct_answer');
        $user_level = $this->post('user_level');
		$user_share = $this->post('user_share');
        $user_tags = $this->post('user_tags');
        $user_language = $this->post('user_language');
		$user_restrict_to = $this->post('user_restrict_to');
        $user_duration = $this->post('user_duration');
		$user_content_type = $this->post('user_content_type');
        $user_pricing = $this->post('user_pricing');
	     
    if(!empty($user_question))
    {
	    $add_quiz = array(
    		'kon_user_id'=> $user_id,
    		'kon_question'=>$user_question,
    		'kon_answer1'=>$user_answer1,
    		'kon_answer2'=>$user_answer2,
    		'kon_answer3'=>$user_answer3,
    		'kon_answer4'=>$user_answer4,
    		'kon_correct_answer'=>$user_correct_answer,
    		'kon_level'=>$user_level,
    		'kon_share'=> $user_share,
    		'kon_tag'=>$user_tags,
    		'kon_language'=>$user_language,
    		'kon_restrict_to'=>$user_restrict_to,
    		'kon_duration'=>$user_duration,
    		'kon_content_type'=>$user_content_type,
    		'pricing'=>$user_pricing,
    		);
	
        $this->db->insert('quiz_list',$add_quiz);
		
		$quiz_last_id =$this->db->insert_id();
			
            $timeLineData = array(
			      'quiz_id'=> $quiz_last_id,
			      'user_id'=> $user_id,
    		      'kon_title'=>$user_question,
    		      'kon_choice1'=>$user_answer1,
    		      'kon_choice2'=>$user_answer2,
    		      'kon_choice3'=>$user_answer3,
    		      'kon_choice4'=>$user_answer4,
    		      'kon_correct_choice'=>$user_correct_answer,
    		      'kon_level'=>$user_level,
    		      'kon_share'=> $user_share,
    		      'kon_tag'=>$user_tags,
    		      'kon_language'=>$user_language,
    		      'kon_restrict_to'=>$user_restrict_to,
    		      'kon_duration'=>$user_duration,
    		      'kon_content_type'=>$user_content_type,
    		      'kon_pricing'=>$user_pricing,
    		      'kon_post_type'=>'Quiz',
			 );
            $this->db->insert('timeLine_posts',$timeLineData);
	      
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_quiz
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
