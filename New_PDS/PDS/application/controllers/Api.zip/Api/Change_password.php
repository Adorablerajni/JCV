<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Change_password extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    /**
     * Get All Data from this method.
     *
     * @return Response
    */

public function index_post()
{
    
	$user_id = $this->post('user_id'); 
	$old_pass = $this->post('old_pass'); 
	$new_pass = $this->post('new_pass'); 
	$con_new_pass = $this->post('con_new_pass');
		
	if(!empty($old_pass))
	{
		$change_pass = array(
    		                 'kon_pswrd'=>$new_pass,
    		                );
		
         $this->db->update('konnect_users',$change_pass,array('id'=>$user_id ));
		 
		 $this->response([
                    'status' => TRUE,
                    'message' => 'Password Changed Successfully',
					'data' => $change_pass
                ], REST_Controller::HTTP_OK);
    }
	else
	{
         $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
    }
}
     
	
}