<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Chat_list extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_get()
{
        $u_id = $this->get('u_id');
        
		
	if(!empty($_GET)) 
		{
		   
		    $query = $this->db->query("SELECT `chat_msg_id`, `chat_id`, `sender_id`, `receiver_id`, `message_type`, `message_content`, `message_status`, `creation_date` FROM chat_msgs WHERE `chat_msg_id` IN (SELECT MAX(`chat_msg_id`) FROM chat_msgs where (chat_msgs.sender_id = '".$u_id."' or chat_msgs.receiver_id = '".$u_id."') AND action_status != 'Delete' GROUP BY `chat_id`)");
             
             
            if ($query->num_rows()>0)
            {
				// $i=0;
				$chatData = array();
                $chatData = $query->result_array();
               
              
               foreach($chatData as $val)
                {
                    
                   $chat_msg_id = $val['chat_msg_id'];
                   $sender = $val['sender_id'];
                    $receiver = $val['receiver_id'];
               
                    if(($u_id == $sender) && ($u_id != $receiver)){
                   $user_kno_id = $receiver;
                   
                    }
                    elseif($u_id == $receiver && $u_id != $sender){
                        
                   $user_kno_id = $sender;
                    }
                    else {
                        $user_kno_id = $sender; 
                    }
                    
               
               $query1 = $this->db->query("SELECT chat_msgs.*, konnect_users.id, konnect_users.kon_name, konnect_users.kon_thumb_pic FROM konnect_users INNER JOIN chat_msgs ON konnect_users.id IN (chat_msgs.sender_id, chat_msgs.receiver_id) where id = '".$user_kno_id."' and chat_msg_id = '".$chat_msg_id."'");
	          
	          if ($query1->num_rows() > 0)
                    {
                        //$data2 = array();
                        $data2[] = $query1->row_array();   
                 
                    }
                    
	             
                }	
                        		
                    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $data2
                ], REST_Controller::HTTP_OK);
                
            }
            else
			{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
            }
            
            
        }
		else
		{
        $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
       }
           
}
}
