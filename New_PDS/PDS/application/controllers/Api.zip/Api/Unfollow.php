<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Unfollow extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
    public function index_post()
	{
		$unfollow_id = $this->post('unfollow_id');
		$unfollow_by = $this->post('unfollow_by');
	
if(!empty($unfollow_id) && !empty($unfollow_by))
{
          $query = $this->db->query("SELECT `id` as friend_id, `sender_id`, `receiver_id`, `status`, `status_date` from friend_list where (receiver_id = '".$unfollow_id."' or sender_id = '".$unfollow_id."') AND (receiver_id = '".$unfollow_by."' or sender_id = '".$unfollow_by."')");
            
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
                $this->db->where('id', $userData['0']['friend_id']);
            $this->db->delete('friend_list');
                
            }
         
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
                ], REST_Controller::HTTP_OK);
                
            }
            else{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
           
    }
}
