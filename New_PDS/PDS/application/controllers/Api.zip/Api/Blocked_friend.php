<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Blocked_friend extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
    public function index_post()
	{
		$blocked_id = $this->post('blocked_id');
		$blocked_by_id = $this->post('blocked_by_id');
		$blocked_date = date("Y-m-d");
	
if(!empty($blocked_id) && !empty($blocked_by_id))
{
	   $query = $this->db->query("SELECT `id` as friend_id, `sender_id`, `receiver_id`, `status`, `status_date` from friend_list where (sender_id = '".$blocked_id."' or receiver_id = '".$blocked_id."') AND (sender_id = '".$blocked_by_id."' or receiver_id = '".$blocked_by_id."')");
            
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
                $this->db->where('id', $userData['0']['friend_id']);
            $this->db->delete('friend_list');
                
            }
	
	
		 $block_friend_status = array(
    		'blocked_user'=> $blocked_id,
    		'blocked_by'=> $blocked_by_id,
    		'status'=> 'Blocked',
			);
			
			 $this->db->insert('blocked_list',$block_friend_status);
		  
        
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
                ], REST_Controller::HTTP_OK);
                
            }
            else{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
           
    }
}
