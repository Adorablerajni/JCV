<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Follow_back extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
	{
		$receiver_id = $this->post('receiver_id');
		$sender_id = $this->post('sender_id');
        $status = $this->post('status');
 	
if(!empty($sender_id) && !empty($receiver_id))
{
	 $current_date = date('Y-m-d'); 
	 
     $add_follow_back = array(
    		'sender_id'=> $receiver_id,
    		'receiver_id'=>$sender_id,
    		'status'=>$status,
    		'status_date'=>$current_date,
    		);
    		
        $this->db->insert('friend_list',$add_follow_back);
	      
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_follow_back
                ], REST_Controller::HTTP_OK);
                
}
else
{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
}
           
}
}
