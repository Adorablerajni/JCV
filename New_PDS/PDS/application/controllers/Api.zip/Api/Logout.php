<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class logout extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_post() 
	{
        
		$user_id = $_POST['user_id'] ;
        $logout_time = date("Y-m-d h:i:s");
        $inactive_logout = 'Inactive';
                
				if(!empty($user_id))
    {
				$logoutdata = array(

                'logout_time'=> $logout_time,
                'login_status'=> $inactive_logout,
                 );
  
                 $this->db->update('user_logs',$logoutdata,array('user_id'=>$user_id));

                //set the response and exit
                $this->response([
                    'status' => TRUE,
                    'message' => 'Logout Successfull.',
					'data' => $logoutdata
                ], REST_Controller::HTTP_OK);
                
            }
            else{
                //set the response and exit
                //echo "Hello";
                //$this->response("Invalid login credential.", REST_Controller::HTTP_BAD_REQUEST);
                $this->response([
                    'status' => FALSE,
                    'message' => 'failed'
                ], REST_Controller::HTTP_OK);
            }

           
    }
}
