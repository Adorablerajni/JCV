<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class View_saved_Text extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_get()
{
        $user_id = $this->get('user_id');
		
	if(!empty($_GET)) 
		{
		$query = $this->db->query("SELECT saved_timeline_post.id as Saved_id, saved_timeline_post.status, saved_timeline_post.timeline_post_id as timeline_id, saved_timeline_post.user_id, timeLine_posts.`kon_link`, timeLine_posts.`kon_choice1`, timeLine_posts.`kon_choice2`, timeLine_posts.`kon_choice3`, timeLine_posts.`kon_choice4`, timeLine_posts.`kon_correct_choice`, timeLine_posts.`kon_question`, timeLine_posts.`kon_textarea`, timeLine_posts.kon_post_type as post_type, timeLine_posts.kon_image, timeLine_posts.kon_title, timeLine_posts.kon_hashtag, timeLine_posts.image_category, timeLine_posts.kon_level, timeLine_posts.kon_share, timeLine_posts.kon_private_content, timeLine_posts.kon_tag, timeLine_posts.kon_language, timeLine_posts.kon_restrict_to, timeLine_posts.kon_duration, timeLine_posts.kon_content_type, timeLine_posts.kon_pricing, timeLine_posts.link_id, timeLine_posts.`poll_id`, timeLine_posts.`quiz_id`, timeLine_posts.`image_id`, timeLine_posts.`scrom_id`, timeLine_posts.`text_id`, timeLine_posts.post_status, timeLine_posts.creation_id, timeLine_posts.user_id as timeline_post_user_id from saved_timeline_post INNER JOIN timeLine_posts on (saved_timeline_post.timeline_post_id = timeLine_posts.id) where saved_timeline_post.user_id = '".$user_id."' and timeLine_posts.kon_post_type = 'Text' ");
            
            if ($query->num_rows() > 0)
            {
				//$userData = array();
                //$userData = $query->result_array();
               
               $data1['savedimage'] = $query->result_array();
                $i=0;
                
                function time_ago( $date )
                {
                    if( empty( $date ) )
                    {
                        return "No date provided";
                    }
                
                    $periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
                
                    $lengths = array("60","60","24","7","4.35","12","10");
                    
                    date_default_timezone_set('Asia/Kolkata'); 
                     $now = time(); 
                     //$currentDate = date('Y-m-d h:ia', $now); 
                
                     $unix_date = strtotime( $date );
                
                    // check validity of date
                
                    if( empty( $unix_date ) )
                    {
                        return "Bad date";
                    }
                
                    // is it future date or past date
                
                    if( $now > $unix_date )
                    {
                        $difference = $now - $unix_date;
                        $tense = "ago";
                    }
                    else
                    {
                        $difference = $unix_date - $now;
                        $tense = "from now";
                    }
                
                    for( $j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++ )
                    {
                        $difference /= $lengths[$j];
                    }
                
                    $difference = round( $difference );
                
                    if( $difference != 1 )
                    {
                        $periods[$j].= "s";
                    }
                
                    return "$difference $periods[$j] {$tense}";
                
                }
                
                foreach($data1['savedimage'] as $val)
                {
                   
                    // $nit = date('d-m-Y H:i:s', strtotime($val['creation_id']));
                    // echo $val['creation_id'];
                    $nit = date('Y-m-d h:ia', strtotime($val['creation_id'])); 
                    $post_time = time_ago($nit);
 
	               
        				$userData[$i] = array(
        
                        								'Saved_id'=>$val['Saved_id'], 
                        								'status'=>$val['status'],
                        								'timeline_id'=>$val['timeline_id'],
                        								'kon_link'=>$val['kon_link'],
                        								'kon_choice1'=>$val['kon_choice1'],
                        								'kon_choice2'=>$val['kon_choice2'], 
                        								'kon_choice3'=>$val['kon_choice3'],
                        								'timeline_id'=>$val['timeline_id'],
                        								'kon_link'=>$val['kon_link'],
                        								'kon_choice1'=>$val['kon_choice1'],
                        								'kon_choice2'=>$val['kon_choice2'], 
                        								'kon_choice3'=>$val['kon_choice3'],
                        								'kon_choice4'=>$val['kon_choice4'],
                        								'kon_correct_choice'=>$val['kon_correct_choice'],
                        								'kon_question'=>$val['kon_question'],
                        								'kon_textarea'=>$val['kon_textarea'], 
                        								'post_type'=>$val['post_type'],
                        								'kon_image'=>$val['kon_image'],
                        								'kon_title'=>$val['kon_title'],
                        								'kon_hashtag'=>$val['kon_hashtag'],
                        								'image_category'=>$val['image_category'], 
                        								'kon_level'=>$val['kon_level'],
                        								'kon_share'=>$val['kon_share'],
                        								'kon_private_content'=>$val['kon_private_content'],
                        								'kon_tag'=>$val['kon_tag'],
                        								'kon_language'=>$val['kon_language'], 
                        								'kon_restrict_to'=>$val['kon_restrict_to'],
                        								'kon_duration'=>$val['kon_duration'],
                        								'kon_content_type'=>$val['kon_content_type'],
                        								'kon_pricing'=>$val['kon_pricing'],
                        								'link_id'=>$val['link_id'], 
                        								'poll_id'=>$val['poll_id'],
                        								'quiz_id'=>$val['quiz_id'],
                        								'image_id'=>$val['image_id'],
                        								'scrom_id'=>$val['scrom_id'],
                        								'text_id'=>$val['text_id'], 
                        								'post_status'=>$val['post_status'],
                        								'timeline_post_user_id'=>$val['timeline_post_user_id'],
                        								'creation_id'=> $post_time
        				
                        			);
        
                          $i++;
                        
              

                }
               
			    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $userData
                ], REST_Controller::HTTP_OK);
            }
            else
			{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
            }
        }
		else
		{
        $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
       }
           
}
}
