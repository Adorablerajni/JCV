<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_comments_response08112019 extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
	    $user_id = $this->post('user_id');
	    $timeline_id = $this->post('timeline_id');
		$comments = $this->post('comments');
		$commented_by_id = $this->post('commented_by_id');
		
		$token = 'd8wnX3iV1To:APA91bHuF4yQXEnBy9t_aGjxMwCmMkA3KvVE2INLwfVuv-Prql3-H1_4N0RRxoS0HLNTt5mW6nY6CTJbHMo7rUIy7L4Vu_Mbjh3_okgk2UkDgHh3XmTKSIwFDkIsFLE7ne8vcgCoWX0J';
		define( 'API_ACCESS_KEY', 'AIzaSyCRLCA6ePLfXu1vLVkm4vuHlYPO-n9aQO0');
		
    if(!empty($user_id) && !empty($timeline_id) && !empty($commented_by_id))
    {
	    $comment_response = array(
    		'post_user_id'=>$user_id,
    		'timeline_post_id'=>$timeline_id,
    		'comments'=>$comments,
    		'commented_by'=>$commented_by_id,
    		);
	     
		 $this->db->insert('timeline_post_comments',$comment_response);
		
	      $add_noti = array(
        		'notification_type'=> 'Post Comment',
        		'sender_id'=>$commented_by_id,
        		'receiver_id'=>$user_id,
        		'post_id'=>$timeline_id,
        		'status'=>'Commented',
        		);
        		
		   $this->db->insert('notification_tbl',$add_noti);
		   
		   $txtPushMessage = $commented_by_id. 'Comment On Your Post.';
		   $txtPushTitle = 'KonnectIn';
		   
                $msg = array
                      (
            		'body' 	=> $txtPushMessage,
            		'title'	=> $txtPushTitle,
            		'click_action'	=> 'com.visuotech.konnectin.OPEN_ACTIVITY'//'com.visuotech.hoshangabad_election.OPEN_ACTIVITY'
                         	
                      );
                      
            	$fields = array
            			(
            				'to'=>$token,    //$_REQUEST['token'],
            				'notification'=> $msg
            			);
	
	
                 $headers = array
                			(
                                'Content-Type:application/json',
                                'Authorization:key='.API_ACCESS_KEY
                
                			);
                			
			//print_r($headers);
			
            #Send Reponse To FireBase Server
            
            		$ch = curl_init();
            		curl_setopt($ch,CURLOPT_URL,'https://fcm.googleapis.com/fcm/send' );
            		curl_setopt($ch,CURLOPT_POST,true);
            		curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
            		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
            		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
            		curl_setopt($ch,CURLOPT_POSTFIELDS, json_encode($fields));
            		$result = curl_exec($ch);
            		//echo $ch;
            		//echo $result;
            		curl_close( $ch );
		   
	      
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $comment_response
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
