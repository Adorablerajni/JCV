<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Edit_user extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
    public function index_post()
	{
		$user_id = $this->post('user_id');
		$user_name = $this->post('user_name');
        $user_email_id = $this->post('user_email_id');
		$user_mobile = $this->post('user_mobile');
		$user_dob = $this->post('user_dob');
        $user_gender = $this->post('user_gender');
        $user_address = $this->post('user_address');
		$user_city = $this->post('user_city');
		$user_state = $this->post('user_state');
        $user_country = $this->post('user_country');
		$user_bio = $this->post('user_bio');
        $user_aadhar = $this->post('user_aadhar');
		$user_pan = $this->post('user_pan');
	
if(!empty($user_email_id) && !empty($user_name))
{
        $add_konnect_users = array(
    		'kon_name'=> $user_name,
    		'kon_email'=>$user_email_id,
    		'kon_mobile'=>$user_mobile,
    		'kon_dob'=>$user_dob,
    		'kon_gender'=> $user_gender,
    		'kon_address'=>$user_address,
    		'kon_city'=>$user_city,
    		'kon_state'=>$user_state,
    		'kon_country'=>$user_country,
    		'kon_bio'=>$user_bio,
    		'kon_aadhar'=>$user_aadhar,
    		'kon_pan'=>$user_pan,
    		
    		);
    		
         $this->db->update('konnect_users',$add_konnect_users,array('id'=>$user_id ));
	      
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_konnect_users
                ], REST_Controller::HTTP_OK);
                
            }
            else{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
           
    }
}
