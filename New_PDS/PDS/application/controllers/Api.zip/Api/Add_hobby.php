<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_hobby extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$user_id = $this->post('user_id');
		$hobby_name_array = $this->post('hobby_name');

	
    if(!empty($user_id) && !empty($hobby_name_array))
    {
        $i = 0;
        foreach($hobby_name_array as $val)
        {
            $hobby_name = $val;
            
            $add_hobbies = array(
            		'user_id'=> $user_id,
            		'hobby_name'=>$hobby_name
            		);
            
            $this->db->insert('hobby_list',$add_hobbies);
            
            $i++;
        }


        $last_id = $this->db->insert_id();
        
        if($last_id!='')
        {
            
        	$this->response([
                'status' => TRUE,
                'message' => 'Success'
        		//'data' => $add_user_education
            ], REST_Controller::HTTP_OK);
        
        }
        else
        {
            
            $this->response([
                'status' => FALSE,
                'message' => 'Failed!!!'
            ], REST_Controller::HTTP_OK);
        
        }
    }
    else
    {

        $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
                
    }
           
}
}
