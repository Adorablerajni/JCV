<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Edit_Featured_images extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    /**
     * Get All Data from this method.
     *
     * @return Response
    */

public function index_post()
{
    
	       $user_id = $this->post('user_id');
		   $image_id = $this->post('image_id');
		
		if (!empty($_FILES['image']['name']))
		{
            $imagename=date("d-m-Y")."-".time();
       
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            if($ext ==='gif' || $ext ==='jpg' || $ext ==='png' || $ext ==='PNG' ||$ext ==='jpeg')
            {
            $config = array(
            'upload_path'   => './upload/Featured_image/',
            'allowed_types' => 'gif|jpg|png|jpeg',
            'max_size' => "2048", // Can be set to particular file size , here it is 2 MB(2048 Kb)
            'file_name'     =>$imagename //"criminal_images!".$imagename
            );        
            $this->load->library('upload');
            $this->upload->initialize($config);
                    
            if(!$this->upload->do_upload('image'))
            {
            $error = array('error' => $this->upload->display_errors());
            echo $this->upload->display_errors() ;
            die("image");
            }
            else
            {
            $imageDetailArray = $this->upload->data();
            $fileName = "Featured_image/".$imagename. '.' .$ext; // $imageDetailArray['file_name'];
            }
            }
		}
		else
	    {
		$fileName='';
		}
		
		
	if(!empty($user_id))
	{
	
		 $featureImageData = array(
               'kon_image'=> $fileName,
                );
		
		$this->db->update('timeLine_posts',$featureImageData,array('id'=>$image_id,'user_id'=>$user_id));
	     	
		    $this->response([
                    'status' => TRUE,
                    'message' => 'Image Uploaded',
					'data' => $featureImageData
                ], REST_Controller::HTTP_OK);
                
    }
	else
    {
    $fileName='';
       
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
		
    } 
     
	
}