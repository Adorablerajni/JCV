<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_scorm extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$user_id = $this->post('user_id');
		$user_file = $this->post('user_file');
        $user_title = $this->post('user_title');
        $user_level = $this->post('user_level');
		$user_share = $this->post('user_share');
		$user_private_content = $this->post('user_private_content');
        $user_tags = $this->post('user_tags');
        $user_language = $this->post('user_language');
		$user_restrict_to = $this->post('user_restrict_to');
        $user_duration = $this->post('user_duration');
		$user_content_type = $this->post('user_content_type');
        $user_pricing = $this->post('user_pricing');
		
		  $imagename=date("d-m-Y")."-".time();
       
            $ext = pathinfo($_FILES['user_file']['name'], PATHINFO_EXTENSION);
            if($ext ==='gif' || $ext ==='jpg' || $ext ==='png' || $ext ==='PNG' ||$ext ==='jpeg' ||$ext ==='pdf')
            {
            $config = array(
            'upload_path'   => './upload/SCORM_file/',
            'allowed_types' => 'gif|jpg|png|jpeg|pdf',
            'max_size' => "2048", // Can be set to particular file size , here it is 2 MB(2048 Kb)
            'file_name'     =>$imagename //"criminal_images!".$imagename
            );        
            $this->load->library('upload');
            $this->upload->initialize($config);
                    
            if(!$this->upload->do_upload('user_file'))
            {
            $error = array('error' => $this->upload->display_errors());
            echo $this->upload->display_errors() ;
            die("user_file");
            }
            else
            {
            $imageDetailArray = $this->upload->data();
            $fileName = "SCORM_file/".$imagename. '.' .$ext; // $imageDetailArray['file_name'];
            }
            }
	     
    if(!empty($user_title))
    {
	    $add_scorm = array(
    		'user_id'=> $user_id,
    		'kon_file'=>$fileName,
    		'kon_title'=>$user_title,
    		'kon_share'=>$user_share,
    		'kon_level'=>$user_level,
    		'kon_private_content'=> $user_private_content,
    		'kon_tag'=>$user_tags,
    		'kon_language'=>$user_language,
    		'kon_restrict_to'=>$user_restrict_to,
    		'kon_duration'=>$user_duration,
    		'kon_content_type'=>$user_content_type,
    		'kon_pricing'=>$user_pricing,
    		);
	
        $this->db->insert('add_scorm',$add_scorm);
	    
        $scorm_last_id =$this->db->insert_id();
			
            $timeLineData = array(
			      'scrom_id'=> $scorm_last_id,
			      'user_id'=> $user_id,
    		      'kon_image'=>$fileName,
    		      'kon_title'=>$user_title,
    		      'kon_level'=>$user_level,
    		      'kon_share'=> $user_share,
    		      'kon_tag'=>$user_tags,
    		      'kon_language'=>$user_language,
    		      'kon_restrict_to'=>$user_restrict_to,
    		      'kon_duration'=>$user_duration,
    		      'kon_content_type'=>$user_content_type,
    		      'kon_pricing'=>$user_pricing,
    		      'kon_post_type'=>'SCORM',
			 );
            $this->db->insert('timeLine_posts',$timeLineData);
			
			
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_scorm
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
