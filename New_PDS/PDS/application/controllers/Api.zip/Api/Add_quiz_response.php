<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_quiz_response extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
	    $quiz_id = $this->post('quiz_id');
		$user_answer = $this->post('user_answer');
		$responed_by_id = $this->post('responed_by_id');
		
    if(!empty($quiz_id) && !empty($user_answer))
    {
	    $quiz_response = array(
    		'kon_quiz_id'=>$quiz_id,
    		'kon_quiz_response'=>$user_answer,
    		'kon_responsed_by'=>$responed_by_id,
    		);
	     
		 $this->db->insert('quiz_response',$quiz_response);
		
	     
	      
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $quiz_response
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
