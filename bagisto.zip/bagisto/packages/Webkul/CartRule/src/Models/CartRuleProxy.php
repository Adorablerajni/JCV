<?php

namespace Webkul\CartRule\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CartRuleProxy extends ModelProxy
{

}
