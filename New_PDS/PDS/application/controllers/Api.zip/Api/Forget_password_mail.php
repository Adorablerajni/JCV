<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Forget_password_mail extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
	$user_email_id = $this->post('user_email_id');
	     
    if(!empty($user_email_id))
    {

		$query = $this->db->query("SELECT * from konnect_users where kon_email = '".$user_email_id."'");
        if ($query->num_rows() > 0)
        {

            $userData['userData'] = $query->row_array();
            
            $to = "".$userData['userData']['kon_email']."" ;  //nitzz.vt@gmail.com //".$email_id." //igp_indore@mppolice.gov.in
            $today = date('d-m-Y');
            $subject = "Reset Password KonnectIn | Date: ".$today."";
            
            // Always set content-type when sending HTML email
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            
            // More headers
            $headers .= 'From: <nitzz.vt@gmail.com>' . "\r\n";
            $headers .= 'Cc: nitzz.vt@gmail.com' . "\r\n";

            $message = 'Hi '.$userData['userData']['kon_name'].', <br /> <br />';
            $message .='We received a request to reset your password for your konnectin account. We are here to help! <br /><br />';
            $message .='Simply click on the link to set a new password. <br /><br />';
            $message .='<a href=https://www.google.com/ >Set a new password</a> <br /><br />';
            $message .='If you did not ask to change your password, do not worry! your password is still safe and you can delete this email. <br /><br /><br/>';
            
            $message .= "Regards, <br />";
            $message .= "KonnectIn Team";
            
            mail($to,$subject,$message,$headers);
            
			    $this->response([
                    'status' => TRUE,
                    'message' => 'Success'
					//'data' => $userData
                ], REST_Controller::HTTP_OK);
        }
        else
		{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
        }

    }
    else
    {
        $this->response([
                'status' => FALSE,
                'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
    }
}
}
