<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Edit_education extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
    public function index_post()
	{
		$ed_id = $this->post('ed_id');
		$user_id = $this->post('user_id');
		$institute_name = $this->post('institute_name');
        $degree = $this->post('degree');
        $filed_of_study = $this->post('filed_of_study');
		$start_year = $this->post('start_year');
		$end_year = $this->post('end_year');
		$description = $this->post('description');
	
if(!empty($institute_name))
{
        $edit_education = array(
    		'institute_name'=> $institute_name,
    		'degree'=>$degree,
    		'filed_of_study'=>$filed_of_study,
    		'start_year'=>$start_year,
    		'end_year'=>$end_year,
    		'description'=> $description,
    		);
    		
         $this->db->update('user_education',$edit_education,array('id'=>$ed_id,'user_id'=>$user_id));
	      
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $edit_education
                ], REST_Controller::HTTP_OK);
                
            }
            else{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
           
    }
}
