<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Saved_timeLine_post extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
	    $timeline_id = $this->post('timeline_id');
		$user_id = $this->post('user_id');
		
		
    if(!empty($timeline_id) && !empty($user_id))
    {
		
		
	    $saved_response = array(
    		'timeline_post_id'=>$timeline_id,
    		'user_id'=>$user_id,
    		);
	     
		 $this->db->insert('saved_timeline_post',$saved_response);
		
	     
	      
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $saved_response
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
