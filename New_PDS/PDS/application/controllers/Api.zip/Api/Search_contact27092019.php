<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Search_contact extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }

 public function index_get() {
        
        $user_name = $this->get('user_name');
     
      $condition="id!=0";
	  
	  if($user_name!='')
        	{
				
        	    $condition .=" and kon_name LIKE '%".$user_name."%' ";
        	  
			
	           $query = $this->db->query("SELECT id, kon_name, kon_email, kon_mobile, kon_pswrd, kon_dob, kon_gender, kon_address, kon_city, kon_state, kon_country, kon_profile_pic, kon_bio, kon_unq_id, kon_device_id, kon_aadhar, kon_pan, kon_status, pofile_type FROM konnect_users where ".$condition."");
	          
		   
		   
              if ($query->num_rows() > 0)
              {
                //$userData = array();
                $data['users'] = $query->result_array();
                $i=0;
                foreach($data['users'] as $val)
                {

				$userData[$i] = array(
 
                								'id'=>$val['id'],
                								'name'=>$val['kon_name'],
                								'pic'=>$val['kon_profile_pic'],
                								'city'=>$val['kon_city']
				
                			);

                  $i++;
                }
                

                    //set the response and exit
                    $this->response([
                        'status' => TRUE,
                        'message' => 'Records fetched successfully.',
                       'data' => $userData], REST_Controller::HTTP_OK);
                }
              else
              {
                    //set the response and exit
                    $this->response([
                        'status' => FALSE,
                        'message' => 'No records found.'
                    ], REST_Controller::HTTP_OK);
               }
            

    }
	else
	{
            //set the response and exit
                $this->response([
                    'status' => FALSE,
                    'message' => 'Required parameters are not available.'
                ], REST_Controller::HTTP_OK);
    }   

    }
	
}