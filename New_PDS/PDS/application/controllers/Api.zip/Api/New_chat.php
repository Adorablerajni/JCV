 <?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class New_chat extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		//$chat_id = $this->post('chat_id');
		$sender_id = $this->post('sender_id');
		$receiver_id = $this->post('receiver_id');
		$message_type = $this->post('message_type');
		$message_content = $this->post('message_content');

	
    if(!empty($sender_id) && !empty($receiver_id) && !empty($message_type) && !empty($message_content))
    {
        $check = $this->db->query("SELECT chat_msgs.* from chat_msgs where (chat_msgs.sender_id = '".$sender_id."' AND chat_msgs.receiver_id = '".$receiver_id."') OR (chat_msgs.sender_id = '".$receiver_id."' AND chat_msgs.receiver_id = '".$sender_id."')");
            
            if ($check->num_rows() > 0)
            {
				$checkData = $check->row_array();
				$usr_chat_id = $checkData['chat_id'];
				//print_r($checkData);
				//die();
            }
            
            else {
                $rand_num =  mt_rand(100000, 999999);
                $usr_chat_id = $sender_id.$rand_num.$receiver_id;
            }
        
            
            $chat = array(
                    'chat_id'=>$usr_chat_id,
            		'sender_id'=>$sender_id,
            		'receiver_id'=> $receiver_id,
            		'message_type'=> $message_type,
            		'message_content'=> $message_content,
            		'message_status'=> "1"
            		);
            
            $this->db->insert('chat_msgs',$chat);
            
        $chat_message_id = $this->db->insert_id();
        
        
        if($chat_message_id!='')
        {
		 
	$query = $this->db->query("SELECT chat_msgs.* from chat_msgs where chat_msg_id = '".$chat_message_id."'");
            
            if ($query->num_rows() > 0)
            {
				$userData = $query->row_array();
            }
            
            $add_noti = array(
        		'notification_type'=> 'New Message',
        		'sender_id'=>$sender_id,
        		'receiver_id'=>$receiver_id,
        		'message_type'=>$message_type,
        		'chat_id'=>$usr_chat_id,
        		'message_content'=>$message_content,
        		'status'=>'Messaged',
        		'noti_status'=>'Inactive',
        		);
		   $this->db->insert('notification_tbl',$add_noti);
		   
        	$this->response([
                'status' => TRUE,
                'message' => 'Success',
        	     'data' => $userData
            ], REST_Controller::HTTP_OK);
        
        }
        else
        {
            
            $this->response([
                'status' => FALSE,
                'message' => 'Failed!!!'
            ], REST_Controller::HTTP_OK);
        
        }
    }
    else
    {

        $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
                
    }
           
}
}
