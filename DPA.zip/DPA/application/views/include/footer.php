<div id="footer" class="hprtbtn navStuff">
  <p>Powered by <a href="http://www.visuotech.com" target="_new">Visuotech Technologies</a></p>
</div>