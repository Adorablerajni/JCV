<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class DeleteExperience extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$experience_id = $this->post('e_id');
		$user_id = $this->post('u_id');
	
        if(!empty($experience_id) && !empty($user_id))
        {
           $query = $this->db->query("SELECT `id` as e_id from user_experience where id = '".$experience_id."' AND user_id = '".$user_id."'");
            
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
                $this->db->where('id', $userData['0']['e_id']);
            $this->db->delete('user_experience');
                
            }
           
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
                ], REST_Controller::HTTP_OK);
                
            }
            else{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
           
    }
}
