<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class View_quizs_response extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_get()
{
        $quiz_id = $this->get('quiz_id');
		
	if(!empty($_GET)) 
		{
		$query = $this->db->query("SELECT quiz_response.id, quiz_response.kon_quiz_response, quiz_response.kon_quiz_id, quiz_response.kon_responsed_by, konnect_users.kon_name from quiz_response INNER JOIN konnect_users on (quiz_response.kon_responsed_by = konnect_users.id) where kon_quiz_id = '".$quiz_id."'");
            
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
               
			    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $userData
                ], REST_Controller::HTTP_OK);
            }
            else
			{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
            }
        }
		else
		{
        $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
       }
           
}
}
