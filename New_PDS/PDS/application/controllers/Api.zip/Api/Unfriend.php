<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Unfriend extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
    public function index_post()
	{
		$user_id = $this->post('user_id');
		$friend_id = $this->post('friend_id');
		$unfriend_time = date("Y-m-d");
	
if(!empty($user_id) && !empty($friend_id))
{
        //$unfriend = array(
    	//	'status'=> 'Unfriend',
    	//	'follow'=> 'No',
		//	'status_date'=> $unfriend_time,
    	//	);
    		$query = $this->db->query("SELECT friend_list.`id` as f_id, friend_list.`receiver_id`, konnect_users.kon_name, konnect_users.kon_city, konnect_users.kon_profile_pic from friend_list INNER JOIN konnect_users on (friend_list.sender_id = konnect_users.id) where (friend_list.receiver_id = '".$friend_id."' or friend_list.sender_id = '".$friend_id."') and (friend_list.receiver_id = '".$user_id."' or friend_list.sender_id = '".$user_id."')");
            
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
                $this->db->where('id', $userData['0']['f_id']);
            $this->db->delete('friend_list');
                
            }
            
            
    		
            
         //$this->db->update('friend_list',$unfriend,array('receiver_id'=>$user_id,'sender_id'=>$friend_id));
	     //$this->db->update('friend_list',$unfriend,array('sender_id'=>$user_id,'receiver_id'=>$friend_id));
	     
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
                ], REST_Controller::HTTP_OK);
                
            }
            else{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
           
    }
}
