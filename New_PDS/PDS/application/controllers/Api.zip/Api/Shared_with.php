<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Shared_with extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
	{
		$user_id = $this->post('user_id');
		$timeline_post_id = $this->post('timeline_post_id');
        $status = $this->post('status');
        $shared_id = $this->post('shared_id');
	
if(!empty($user_id))
{
     $add_status = array(
    		'user_id'=> $user_id,
    		'shared_with'=>$shared_id,
    		'timeline_post_id'=>$timeline_post_id,
    		'shared_status'=>$status,
    		);
    		
        $this->db->insert('shared_with',$add_status);
        
        $update_status = array(
    		'shared_with'=>$status,
    		);
    		
        $this->db->update('timeLine_posts',$update_status,array('id'=>$timeline_post_id,'user_id'=>$user_id));
	     
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_status
                ], REST_Controller::HTTP_OK);
                
}
else
{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
}
           
}
}
