<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_poll_response extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
	    $poll_id = $this->post('poll_id');
		$user_choice = $this->post('user_choice');
		$responed_by_id = $this->post('responed_by_id');
		
    if(!empty($poll_id) && !empty($user_choice))
    {
	    $poll_response = array(
    		'kon_poll_id'=>$poll_id,
    		'kon_poll_response'=>$user_choice,
    		'kon_responsed_by'=>$responed_by_id,
    		);
	     
		 $this->db->insert('poll_response',$poll_response);
		
	     
	      
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $poll_response
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
