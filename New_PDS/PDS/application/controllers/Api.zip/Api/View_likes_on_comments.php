<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class View_likes_on_comments extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_get()
{
        $post_id = $this->get('post_id');
        $comment_id = $this->get('comment_id');
		
	if(!empty($_GET)) 
		{
		$query = $this->db->query("SELECT likes_on_comment.id, likes_on_comment.liked_by, konnect_users.kon_name, konnect_users.kon_profile_pic from likes_on_comment INNER JOIN konnect_users on (likes_on_comment.liked_by = konnect_users.id) where likes_on_comment.timeline_post_id = '".$post_id."' AND likes_on_comment.comment_id = '".$comment_id."' AND likes_on_comment.like_status ='Yes' ");
            
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
               
			    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $userData
                ], REST_Controller::HTTP_OK);
            }
            else
			{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
            }
        }
		else
		{
        $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
       }
           
}
}
