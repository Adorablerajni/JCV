<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_respones_on_comment extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
	    $timeline_post_id = $this->post('timeline_post_id');
		$comment_id = $this->post('comment_id');
		$like_status = $this->post('like_status');
		$comments = $this->post('comments');
		$responsed_by = $this->post('responsed_by');
		
		
    if(!empty($timeline_post_id) && !empty($comment_id) && !empty($responsed_by))
    {
	    $add_response = array(
    		'timeline_post_id'=>$timeline_post_id,
    		'comment_id'=>$comment_id,
    		'like_status'=>$like_status,
    		'comments'=>$comments,
    		'responsed_by'=>$responsed_by,
    		);
	     
		 $this->db->insert('reply_on_comments',$add_response);
		
		$add_noti = array(
        		'notification_type'=> 'Comment on Comment',
        		'commented_by'=>$responsed_by,
        		'post_id'=>$timeline_post_id,
        		'comment_id'=>$comment_id,
        		'status'=>'Commented',
        		);
		   $this->db->insert('notification_tbl',$add_noti);
	     
	      
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_response
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
