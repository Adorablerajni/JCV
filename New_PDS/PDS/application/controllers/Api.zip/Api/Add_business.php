<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_business extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
	{ 
		$user_id = $this->post('user_id');
		$business_name = $this->post('b_name');
        //$business_logo = $this->post('b_logo');
		$business_mobile = $this->post('b_mobile');
		$business_address = $this->post('b_address');
        $business_lat = $this->post('b_lat');
		$business_long = $this->post('b_long');
		$business_category = $this->post('b_category');
		$business_desc = $this->post('b_desc');
		$business_timing = $this->post('b_timing');
		$business_email = $this->post('b_email');
		$business_alt_email = $this->post('b_alt_email');
		$business_website = $this->post('b_website');
		$business_alt_website = $this->post('b_alt_website');
        //$business_services[] = $this->post('b_services');
        
if(!empty($user_id))
{
    if($_FILES['b_logo']['name']!=''){
        
   
    $imagename = date("d-m-Y")."-".time(); 
                        
                        $ext = pathinfo($_FILES['b_logo']['name'], PATHINFO_EXTENSION);
                        if($ext ==='jpg' || $ext ==='png' || $ext ==='PNG' ||$ext ==='jpeg')
                        {
                            $config1 = array(
                            'upload_path'   => './upload/Business_Logo/',
                            'allowed_types' => 'jpg|png|jpeg',
                            'max_size' => "2048", // Can be set to particular file size , here it is 2 MB(2048 Kb)
                            'file_name' =>$imagename //"criminal_images!".$imagename
                            ); 
                            
                            $this->load->library('upload');
                            $this->upload->initialize($config1);
                                    
                            if(!$this->upload->do_upload('b_logo'))
                            {
                            $error = array('error' => $this->upload->display_errors());
                            echo $this->upload->display_errors() ;
                            die("b_logo");
                            }
                            else
                            {
                            $imageDetailArray = $this->upload->data();
                            $fileName = "Business_Logo/".$imagename. '.' .$ext; // $imageDetailArray['file_name'];
                            }
                        }
                        
    }
    else{
        $fileName='';
    }
                        
                        
        $add_business = array(
    		'user_id'=> $user_id,
    		'business_name'=>$business_name,
    		'business_logo'=>$fileName,
    		'business_mobile'=>$business_mobile,
    		'business_address'=> $business_address,
    		'business_lat'=>$business_lat,
    		'business_long'=>$business_long,
    		'business_category'=>$business_category,
    		'business_desc'=>$business_desc,
    		'business_timing'=>$business_timing,
    		'business_email'=>$business_email,
    		'business_alt_email'=>$business_alt_email,
    		'business_website'=>$business_website,
    		'business_alt_website'=>$business_alt_website
    		//'business_services'=>$business_services
    		);
    		
        $this->db->insert('business_details',$add_business);
	      
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_business
                ], REST_Controller::HTTP_OK);
                
}
else
{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
}
           
}
}
