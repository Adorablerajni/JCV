<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Delete_post extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$user_id = $this->post('user_id');
		$post_id = $this->post('post_id');
	
        if(!empty($post_id) && !empty($user_id))
        {
           $query = $this->db->query("SELECT `id` as post_id, `kon_post_type`, `kon_title`, `kon_link`, `kon_choice1`, `kon_choice2`, `kon_choice3`, `kon_choice4`, `kon_correct_choice`, `kon_question`, `kon_image`, `kon_textarea`, `image_category`, `kon_level`, `kon_share`, `kon_private_content`, `kon_tag`, `kon_language`, `kon_restrict_to`, `kon_duration`, `kon_content_type`, `kon_pricing`, `link_id`, `poll_id`, `quiz_id`, `image_id`, `scrom_id`, `text_id`, `user_id` from timeLine_posts where id = '".$post_id."' AND user_id = '".$user_id."'");
            
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
                $this->db->where('id', $userData['0']['post_id']);
                $this->db->delete('timeLine_posts');
                
            }
           
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
                ], REST_Controller::HTTP_OK);
                
            }
            else{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
           
    }
}
