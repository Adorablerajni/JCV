<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Accept_request extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
    public function index_post()
	{
		$r_id = $this->post('r_id');
		$s_id = $this->post('s_id');
		$accepted_time = date("Y-m-d h:m:s");
	
if(!empty($r_id) && !empty($r_id))
{
        $accept_req = array(
    		'status'=> 'Followers',
			'status_date'=> $accepted_time,
    		);
    		
         $this->db->update('friend_list',$accept_req,array('receiver_id'=>$r_id,'sender_id'=>$s_id));
	      
		    
         $add_noti = array(
        		'notification_type'=> 'Accept Request',
        		'sender_id'=>$r_id,
        		'receiver_id'=>$s_id,
        		'status'=>'Accepted',
        		);
		   $this->db->insert('notification_tbl',$add_noti);
		  
		  
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $accept_req
                ], REST_Controller::HTTP_OK);
                
            }
            else{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
           
    }
}
