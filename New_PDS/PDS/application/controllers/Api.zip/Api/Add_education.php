<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_education extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
	{
		$user_id = $this->post('user_id');
		$user_institute_name = $this->post('user_institute_name');
        $user_degree = $this->post('user_degree');
		$user_filed_of_study = $this->post('user_filed_of_study');
		$user_start_year = $this->post('user_start_year');
        $user_end_year = $this->post('user_end_year');
		$user_description = $this->post('user_description');
	
if(!empty($user_id))
{
     $add_user_education = array(
    		'user_id'=> $user_id,
    		'institute_name'=>$user_institute_name,
    		'degree'=>$user_degree,
    		'filed_of_study'=>$user_filed_of_study,
    		'start_year'=> $user_start_year,
    		'end_year'=>$user_end_year,
    		'description'=>$user_description,
    		);
    		
        $this->db->insert('user_education',$add_user_education);
	      
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_user_education
                ], REST_Controller::HTTP_OK);
                
}
else
{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
}
           
}
}
