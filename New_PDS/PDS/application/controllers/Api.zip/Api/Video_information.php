<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Video_information extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
	{
		$user_id = $this->post('user_id');
		$video_id = $this->post('video_id');
        $media_type = $this->post('media_type');
		$start_time = $this->post('start_time');
		$end_time = $this->post('end_time');
        $privacy_status = $this->post('privacy_status');
	
if(!empty($video_id))
{
     $add_video_info = array(
    		'user_id'=> $user_id,
    		'video_id'=>$video_id,
    		'media_type'=>$media_type,
    		'start_time'=>$start_time,
    		'end_time'=> $end_time,
    		'privacy_status'=>$privacy_status,
    		);
    		
        $this->db->insert('video_uploaded',$add_video_info);
	      
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_video_info
                ], REST_Controller::HTTP_OK);
                
}
else
{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
}
           
}
}
