<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Reply_on_comment extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
	    $post_id = $this->post('post_id');
		$comment_id = $this->post('comment_id');
		$comments = $this->post('comments');
		$commented_by_id = $this->post('commented_by_id');
		
		
    if(!empty($post_id) && !empty($comment_id) && !empty($commented_by_id))
    {
	    $comment_response = array(
    		'timeline_post_id'=>$post_id,
    		'comment_id'=>$comment_id,
    		'comments'=>$comments,
    		'commented_by'=>$commented_by_id,
    		);
	     
		 $this->db->insert('reply_on_comments',$comment_response);
		
	     $add_noti = array(
        		'notification_type'=> 'Comment on Comment',
        		'sender_id'=>$commented_by_id,
        		'post_id'=>$post_id,
        		'comment_id'=>$comment_id,
        		'status'=>'Commented',
        		);
		   $this->db->insert('notification_tbl',$add_noti);
	     
	      
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $comment_response
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
