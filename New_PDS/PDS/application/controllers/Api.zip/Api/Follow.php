<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Follow extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
	{
		$sender_id = $this->post('sender_id');
		$receiver_id = $this->post('receiver_id');
        $status = $this->post('status');
 	    $receiver_profile_status = $this->post('receiver_profile_status');
 	    
if(!empty($sender_id) && !empty($receiver_id) && !empty($receiver_profile_status))
{
	 $current_date = date('Y-m-d'); 
	 
  
         $add_friend = array(
        		'sender_id'=> $sender_id,
        		'receiver_id'=>$receiver_id,
        		'status'=>$status,
        		'status_date'=>$current_date,
        		);
	     
	 
	 
        $this->db->insert('friend_list',$add_friend);
	      
         $add_noti = array(
        		'notification_type'=> 'Friend Request',
        		'sender_id'=>$sender_id,
        		'receiver_id'=>$receiver_id,
        		'status'=>'Requested',
        		);
		   $this->db->insert('notification_tbl',$add_noti);
 
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_friend
                ], REST_Controller::HTTP_OK);
                
}
else
{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
}
           
}
}
