<?php

namespace Webkul\CartRule\Contracts;

interface CartRule
{
}