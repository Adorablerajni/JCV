<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class View_timeline_scorm extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_get()
{
        $user_id = $this->get('user_id');
		
	if(!empty($_GET)) 
		{
		$query = $this->db->query("SELECT `id`, `kon_file`, `kon_title`, `kon_level`, `kon_share`, `kon_private_content`, `kon_tag`, `kon_language`, `kon_restrict_to`, `kon_duration`, `kon_content_type`, `kon_pricing`, `user_id` from add_scorm where user_id = '".$user_id."'");
            
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
               
			    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $userData
                ], REST_Controller::HTTP_OK);
            }
            else
			{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
            }
        }
		else
		{
        $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
       }
           
}
}
