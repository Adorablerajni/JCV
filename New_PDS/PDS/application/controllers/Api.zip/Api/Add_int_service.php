<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_int_service extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
   
		$user_id = $this->post('user_id');
		$service_name = $this->post('service_name');
		$service_type = $this->post('service_type');
		$app_id = $this->post('app_id');
		$app_key = $this->post('app_key');
		$status = $this->post('status');
	     
    if(!empty($app_id))
    {
	    $add_service = array(
    		'int_user_id'=> $user_id,
    		'int_src_name'=>$service_name,
    		'int_src_type'=>$service_type,
    		'int_app_id'=>$app_id,
    		'int_app_key'=>$app_key,
    		'int_status'=>$status
    		);
	
        $this->db->insert('integration_services',$add_service);
		
	//	$service_last_id =$this->db->insert_id();
			
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
    
		
}
}
