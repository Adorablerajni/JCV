<?php
namespace App\Http\Controllers\Admin\Auth;
use Illuminate\Http\Request; 
//\Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\Providers\RouteServiceProvider;
 
class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */
 
    use AuthenticatesUsers;
 
    /**
     * Where to redirect users after login.
     *
     * @var string
     */
   protected $redirectTo =  '/admin/home';
 
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest:admin')->except('logout');
    }
    protected function guard()
    {   
        
        return \Auth::guard('admin');
    }
    /**
     * Show the application's login form.
     *
     * @return \Illuminate\Http\Response
     */
    public function showLoginForm()
    {
        
        return view('auth.admin.login');
    }
    protected function authenticated(Request $request, $user)
    {
        echo "<pre>";
        print_r($request);
        echo "</pre>";
        echo "<pre>";
        print_r($user);
        echo "</pre>";die;
        return response([
            //
        ]);
    }
    public function username()
    {
        return 'username';
    }
 
}	