<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Acc_privacy extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
        $user_id = $this->post('user_id');
        $status = $this->post('status');
		
		
     if($status== 'Public')
     {
		 
     $add_privacy = array(
    		'account_status'=>'Private',
    		);
			
	   $this->db->update('konnect_users',$add_privacy,array('id'=>$user_id));
	 }
     else 
	 {		 
	   $add_privacy = array(
    		'account_status'=>'Public',
    		);
			
		 $this->db->update('konnect_users',$add_privacy,array('id'=>$user_id));
	 }
    		
        
	    
	      
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_privacy
                ], REST_Controller::HTTP_OK);
                


           
}
}
