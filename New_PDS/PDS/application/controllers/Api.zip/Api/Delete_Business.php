<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Delete_Business extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$business_id = $this->post('b_id');
		$user_id = $this->post('u_id');
	
        if(!empty($business_id) && !empty($user_id))
        {
           $query = $this->db->query("SELECT `id` as b_id from business_details where id = '".$business_id."' AND user_id = '".$user_id."'");
            
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
                $this->db->where('id', $userData['0']['b_id']);
            $this->db->delete('business_details');
                
            }
           
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
                ], REST_Controller::HTTP_OK);
                
            }
            else{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
           
    }
}
