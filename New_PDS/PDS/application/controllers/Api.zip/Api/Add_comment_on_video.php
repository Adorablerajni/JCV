<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_comment_on_video extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
	{
		$user_id = $this->post('user_id');
		$video_id = $this->post('video_id');
        $comment = $this->post('comment');
	
if(!empty($video_id))
{
     $add_comment = array(
    		'user_id'=> $user_id,
    		'video_id'=>$video_id,
    		'comment'=>$comment,
    		);
    		
        $this->db->insert('show_comment',$add_comment);
	      
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_comment
                ], REST_Controller::HTTP_OK);
                
}
else
{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
}
           
}
}
