<?php

namespace Webkul\CartRule\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CartRuleCouponProxy extends ModelProxy
{

}