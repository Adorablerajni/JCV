<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Actions_on_chats extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$user_id = $this->post('user_id');
		$chat_id = $this->post('chat_id');
		$status = $this->post('status');
		
    if(!empty($user_id))
    {
        $module_id = $chat_id;
        foreach($module_id as $value)
    {
	    $add_action = array(
		    'action_status'=>$status,
    		'action_by'=>$user_id,
    		);
	     
		$this->db->update('chat_msgs',$add_action,array('chat_id'=>$chat_id));
    }
	     
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_action
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
