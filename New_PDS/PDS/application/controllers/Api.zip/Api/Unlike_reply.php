<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Unlike_reply extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$user_id = $this->post('user_id');
		$post_id = $this->post('post_id');
		$comment_id = $this->post('comment_id');
		$reply_id = $this->post('reply_id');
	
    if(!empty($user_id) && !empty($post_id) && !empty($comment_id) && !empty($reply_id))
    {
        
     $query = $this->db->query("SELECT `id`, `post_id`, `comment_id`, `reply_id`, `liked_by`, `like_status` from reply_like where liked_by = '".$user_id."' AND post_id = '".$post_id."' AND comment_id = '".$comment_id."' AND reply_id = '".$reply_id."'");
		 
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
                $this->db->where('id', $userData['0']['id']);
                $this->db->delete('reply_like');
           
	            $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
                ], REST_Controller::HTTP_OK);
            }
            else
			{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            }
           
    }
}
}
