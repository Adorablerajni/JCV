<?php

namespace Webkul\CartRule\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CartRuleCouponUsageProxy extends ModelProxy
{
}