<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_likes_on_comment extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
	    $timeline_post_id = $this->post('timeline_post_id');
		$comment_id = $this->post('comment_id');
		$liked__by = $this->post('liked__by');
		
		
    if(!empty($timeline_post_id) && !empty($comment_id) && !empty($liked__by))
    {
		$status = 'Yes';
	    $add_response = array(
    		'timeline_post_id'=>$timeline_post_id,
    		'like_status'=>$status,
    		'comment_id'=>$comment_id,
    		'liked_by'=>$liked__by,
    		);
	     
		 $this->db->insert('likes_on_comment',$add_response);
		
	     $add_noti = array(
        		'notification_type'=> 'Comment Like',
        		'sender_id'=>$liked__by,
        		'post_id'=>$timeline_post_id,
        		'comment_id'=>$comment_id,
        		'status'=>'Liked',
        		);
		   $this->db->insert('notification_tbl',$add_noti);
	      
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_response
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
