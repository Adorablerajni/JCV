<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Cities extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_get()
{
        $state_id = $this->get('s_id');
		
	if(!empty($_GET)) 
		{
		    //echo $state_id;
		$query = $this->db->query("SELECT DISTINCT(cityname) FROM `sys_city` WHERE stateid = '".$state_id."' and `status` = 1 order by cityname asc");
            
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
               //print_r($userData);
               
			    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $userData
                ], REST_Controller::HTTP_OK);
            }
            else
			{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
            }
        }
		else
		{
        $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
       }
           
}
}
