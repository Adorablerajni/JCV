<?php

namespace Webkul\CartRule\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CartRuleTranslationProxy extends ModelProxy
{

}
