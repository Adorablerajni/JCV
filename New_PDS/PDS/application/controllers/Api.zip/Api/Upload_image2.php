<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Upload_image2 extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    /**
     * Get All Data from this method.
     *
     * @return Response
    */

public function index_post()
{
   
	$user_id = $this->post('user_id');
		
if(!empty($user_id))
	{
		  if (!empty($_FILES['image']['name']))
		   {    
        
            $imagename=date("d-m-Y")."-".time();
            $imagename2=date("d-m-Y")."-".time();
       
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            if($ext ==='jpg' || $ext ==='png' || $ext ==='PNG' ||$ext ==='jpeg')
            {
            $config = array(
            'upload_path'   => './upload/Profile_image/',
            'allowed_types' => 'jpg|png|jpeg',
            'max_size' => "2048", // Can be set to particular file size , here it is 2 MB(2048 Kb)
            'file_name'     =>$imagename //"criminal_images!".$imagename
            );        
            $this->load->library('upload');
            $this->upload->initialize($config);
                    
            if(!$this->upload->do_upload('image'))
            {
            $error = array('error' => $this->upload->display_errors());
            echo $this->upload->display_errors() ;
            die("image");
            }
            else
            {
            $imageDetailArray = $this->upload->data();
            $fileName = "Profile_image/".$imagename. '.' .$ext; // $imageDetailArray['file_name'];
            }
            
            
            ///////////// IMAGE THUMB ////////////////////////////
            
            $config['upload_path'] = './upload/Profile_image/thumbs/';
        $config['allowed_types'] = 'jpg|jpeg|png';   // upload only valid images            
        // update library setting of upload
        $this->load->library('upload', $config);
        //upload image 
        $this->upload->do_upload('image');
        $fInfo = $this->upload->data(); // get all info of uploaded file

        //for image resize
        $img_array = array();
        $img_array['image_library'] = 'gd2';
        $img_array['maintain_ratio'] = TRUE;
        $img_array['create_thumb'] = TRUE;
        //you need this setting to tell the image lib which image to process
        $img_array['source_image'] = $fInfo['full_path'];
        $img_array['width'] = 113;
        $img_array['height'] = 75;

        $this->load->library('upload');
        //$this->upload->clear(); // added this line
        $this->upload->initialize($img_array); // added this line
        if (!$this->upload->resize())
        {
            echo $this->upload->display_errors(); exit;
        }
        
            
            ///////////// IMAGE THUMB ////////////////////////////
            
            }
       
		$imageData = array(
		                    
                            'kon_profile_pic'=>$fileName,
                            'kon_thumb_pic'=>$fInfo['file_name'],
							);
    		
         $this->db->update('konnect_users',$imageData,array('id'=>$user_id ));
		 
		 $uploaddata = array(
		       'user_id'=>$user_id,
               'uploaded_image'=> $fileName,
                );
				
         $this->db->insert('upload_image',$uploaddata);
		  
		 $this->response([
                    'status' => TRUE,
                    'message' => 'Image Uploaded',
					'data' => $imageData
                ], REST_Controller::HTTP_OK);
                
            }
	
		else
			{
        $fileName='';
       
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
		}else{
            
                $this->response([
                    'status' => FALSE,
                    'message' => 'Required parameters are not available.'
                ], REST_Controller::HTTP_BAD_REQUEST);
            //$this->response("Required parameters are not available.", REST_Controller::HTTP_BAD_REQUEST);
        }
    } 
     
	
}