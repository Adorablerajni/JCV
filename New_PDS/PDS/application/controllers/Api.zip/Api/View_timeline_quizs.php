<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class View_timeline_quizs extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_get()
{
        $user_id = $this->get('user_id');
		
	if(!empty($_GET)) 
		{
		$query = $this->db->query("SELECT `id` as quiz_id, `kon_question`, `kon_answer1`, `kon_answer2`, `kon_answer3`, `kon_answer4`, `kon_correct_answer`, `kon_level`, `kon_share`, `kon_tag`, `kon_private_content`, `kon_user_id`, `kon_language`, `kon_restrict_to`, `kon_duration`, `kon_content_type`, `pricing` from quiz_list where kon_user_id = '".$user_id."'");
            
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
               
			    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $userData
                ], REST_Controller::HTTP_OK);
            }
            else
			{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
            }
        }
		else
		{
        $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
       }
           
}
}
