<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Unblocked_friend extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
    public function index_post()
	{
		$blocked_id = $this->post('blocked_id');
		$blocked_by_id = $this->post('blocked_by_id');
	
if(!empty($blocked_id) && !empty($blocked_by_id))
{
	   $query = $this->db->query("SELECT `id` as block_id, `blocked_user`, `blocked_by`, `status` from blocked_list where blocked_user = '".$blocked_id."' AND blocked_by = '".$blocked_by_id."' ");
            
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
                $this->db->where('id', $userData['0']['block_id']);
            $this->db->delete('blocked_list');
                
            }
	
	
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
                ], REST_Controller::HTTP_OK);
                
            }
            else{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
           
    }
}
