<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class View_saved_status extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_get()
{
        $user_id = $this->get('user_id');
        $timeline_post_id = $this->get('timeline_post_id');
		
	if(!empty($_GET)) 
		{
		$query = $this->db->query("SELECT status from saved_timeline_post where user_id = '".$user_id."' and timeline_post_id = '".$timeline_post_id."'");
            
            if ($query->num_rows() > 0)
            {
				
                $userData = $query->row_array();
               
			    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $userData
                ], REST_Controller::HTTP_OK);
            }
            else
			{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
            }
        }
		else
		{
        $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
       }
           
}
}
