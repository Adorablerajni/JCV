<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Unlike_on_comment extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$timeline_post_id = $this->post('timeline_post_id');
		$comment_id = $this->post('comment_id');
		$user_id = $this->post('user_id');
	
    if(!empty($user_id) && !empty($timeline_post_id) && !empty($comment_id))
    {
        
     $query = $this->db->query("SELECT id, timeline_post_id, like_status, liked_by from likes_on_comment where liked_by = '".$user_id."' AND timeline_post_id = '".$timeline_post_id."' AND comment_id = '".$comment_id."'");
		 
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
                $this->db->where('id', $userData['0']['id']);
                $this->db->delete('likes_on_comment');
           
	            $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
                ], REST_Controller::HTTP_OK);
            }
            else
			{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            }
           
    }
}
}
