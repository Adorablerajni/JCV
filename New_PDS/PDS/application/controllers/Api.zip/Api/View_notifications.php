<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class View_notifications extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
public function __construct() 
{
       parent::__construct();
       $this->load->database();
}
       
public function index_get()
{
  $user_id = $this->get('user_id');
		
  if(!empty($_GET)) 
  {
			
   $query = $this->db->query("SELECT notification_tbl.id , notification_tbl.notification_type, notification_tbl.sender_id, notification_tbl.receiver_id, notification_tbl.status, notification_tbl.post_id, notification_tbl.comment_id, notification_tbl.reply_id, notification_tbl.noti_status, notification_tbl.seen_status, notification_tbl.creation_date, notification_tbl.chat_id, notification_tbl.message_type, notification_tbl.message_content, konnect_users.kon_name, konnect_users.kon_profile_pic from notification_tbl INNER JOIN konnect_users on (notification_tbl.sender_id = konnect_users.id) where notification_tbl.receiver_id = '".$user_id."'  order by  notification_tbl.id desc");
           
    if ($query->num_rows() > 0)
    {
		//$userData = array();
        //$userData = $query->result_array();
    
    $data1['viewnotification'] = $query->result_array();
$i=0;
                
function time_ago( $date )
{
if( empty( $date ) )
{
return "No date provided";
}
                
$periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
                
$lengths = array("60","60","24","7","4.35","12","10");

date_default_timezone_set('Asia/Kolkata'); 
$now = time(); 
                     //$currentDate = date('Y-m-d h:ia', $now); 
                
$unix_date = strtotime( $date );
                
                    // check validity of date
                
if( empty( $unix_date ) )
{
return "Bad date";
}
                
                    // is it future date or past date
                
if( $now > $unix_date )
{
$difference = $now - $unix_date;
$tense = "ago";
}
else
{
$difference = $unix_date - $now;
$tense = "from now";
}
                
for( $j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++ )
{
$difference /= $lengths[$j];
}
                
$difference = round( $difference );
                
if( $difference != 1 )
{
$periods[$j].= "s";
}
                
return "$difference $periods[$j] {$tense}";
                
}
                
foreach($data1['viewnotification'] as $val)
{
                   
$nit = date('Y-m-d h:ia', strtotime($val['creation_date'])); 
$post_time = time_ago($nit);

$userData[$i] = array(
'id'=>$val['id'],
'notification_type'=>$val['notification_type'],
'sender_id'=>$val['sender_id'], 
'receiver_id'=>$val['receiver_id'], 
'status'=>$val['status'],
'post_id'=>$val['post_id'],
'comment_id'=>$val['comment_id'],
'reply_id'=>$val['reply_id'],
'noti_status'=>$val['noti_status'],
'seen_status'=>$val['seen_status'],
'chat_id'=>$val['chat_id'],
'message_type'=>$val['message_type'],
'message_content'=>$val['message_content'],
'kon_name'=>$val['kon_name'],
'kon_profile_pic'=>$val['kon_profile_pic'],
'creation_date'=> $post_time
);
$i++;
}

	    $this->response([
                'status' => TRUE,
                'message' => 'Success',
				'data' => $userData
                ], REST_Controller::HTTP_OK);
 
	        }
	

       else
			{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
            }
        
	}
		else
		{
       $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
       }
           
}
}
