<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Edit_vCard extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
    public function index_post()
	{
	    $id = $this->post('id');
	    $user_id = $this->post('user_id');
		$vcard_email = $this->post('email');
		$vcard_mobile = $this->post('mobile');
        $vcard_alt_mobile = $this->post('alt_mobile');
		$vcard_address = $this->post('address');
		$vcard_website = $this->post('website');
	
if(!empty($user_id) && !empty($id))
{
        $edit_vcard = array(
    		'vcard_email'=>$vcard_email,
    		'vcard_mobile'=> $vcard_mobile,
    		'vcard_alt_mobile'=>$vcard_alt_mobile,
    		'vcard_address'=>$vcard_address,
    		'vcard_website'=>$vcard_website
    		
    		);
    		
         $this->db->update('vcard_details',$edit_vcard,array('id'=>$id ));
	      
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $edit_vcard
                ], REST_Controller::HTTP_OK);
                
            }
            else{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
           
    }
}
