<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Notification_status_update extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
    public function index_post()
	{
		$notification_id = $this->post('notification_id');
	
if(!empty($notification_id))
{
        $edit_status = array(
    		'seen_status'=> 'Seen'
    		);
    		
         $this->db->update('notification_tbl',$edit_status,array('id'=>$notification_id));
	      
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $edit_status
                ], REST_Controller::HTTP_OK);
                
            }
            else{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
           
    }
}
