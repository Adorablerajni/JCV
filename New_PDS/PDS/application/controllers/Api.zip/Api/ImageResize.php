<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class ImageResize extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    /**
     * Get All Data from this method.
     *
     * @return Response
    */

public function index_post()
{
   
	$user_id = $this->post('user_id');
		
        if(!empty($user_id))
	    {

		    if (!empty($_FILES['image_name']['name']))
		    { 

                for($i=1;$i<=2;$i++)
                {
                    if($i===1)
                    {
                        $imagename = date("d-m-Y")."-".time(); 
                        
                        $ext = pathinfo($_FILES['image_name']['name'], PATHINFO_EXTENSION);
                        if($ext ==='jpg' || $ext ==='png' || $ext ==='PNG' ||$ext ==='jpeg')
                        {
                            $config1 = array(
                            'upload_path'   => './upload/Profile_image/',
                            'allowed_types' => 'jpg|png|jpeg',
                            'max_size' => "2048", // Can be set to particular file size , here it is 2 MB(2048 Kb)
                            'file_name' =>$imagename //"criminal_images!".$imagename
                            ); 
                            
                            $this->load->library('upload');
                            $this->upload->initialize($config1);
                                    
                            if(!$this->upload->do_upload('image_name'))
                            {
                            $error = array('error' => $this->upload->display_errors());
                            echo $this->upload->display_errors() ;
                            die("image_name");
                            }
                            else
                            {
                            $imageDetailArray = $this->upload->data();
                            $fileName = "Profile_image/".$imagename. '.' .$ext; // $imageDetailArray['file_name'];
                            }
                        }
            
                    }
                    else
                    {  
                        $imagename2 = date("d-m-Y")."-".time();
                        
                        $ext = pathinfo($_FILES['image_name']['name'], PATHINFO_EXTENSION);
                        if($ext ==='jpg' || $ext ==='png' || $ext ==='PNG' ||$ext ==='jpeg')
                        {
                            //set preferences
                            //file upload destination
                            $upload_path = './upload/Profile_image/'; //thumbs/
                            $config['upload_path'] = $upload_path;
                            //allowed file types. * means all types
                            $config['allowed_types'] = 'jpg|png|jpeg';
                            //allowed max file size. 0 means unlimited file size
                            $config['max_size'] = '0';
                            //max file name size
                            $config['max_filename'] = '255';
                            //$config['file_name'] = $imagename2 ;
                            //whether file name should be encrypted or not
                            $config['encrypt_name'] = TRUE;
                            //store image info once uploaded
                            $image_data = array();
                            //check for errors
                            $is_file_error = FALSE;
                            
                            //check if file was selected for upload
                            if (!$_FILES) {
                                $is_file_error = TRUE;
                                $this->handle_error('Select an image file.');
                            }
                            
                            //if file was selected then proceed to upload
                            if (!$is_file_error) {
                                //load the preferences
                                $this->load->library('upload', $config);
                                //check file successfully uploaded. 'image_name' is the name of the input
                                if (!$this->upload->do_upload('image_name')) {
                                    //if file upload failed then catch the errors
                                    $this->handle_error($this->upload->display_errors());
                                    $is_file_error = TRUE;
                                } else {
                                    //store the file info
                                    $image_data = $this->upload->data();
                                    $config['image_library'] = 'gd2';
                                    $config['source_image'] = $image_data['full_path']; //get original image
                                    $config['maintain_ratio'] = TRUE;
                                    $config['width'] = 150;
                                    $config['height'] = 100;
                                    $this->load->library('image_lib', $config);
                                    if (!$this->image_lib->resize()) {
                                        $this->handle_error($this->image_lib->display_errors());
                                    }
                                }
                            }
                            
                            // There were errors, we have to delete the uploaded image
                            if ($is_file_error) 
                            {
                                if ($image_data) 
                                {
                                    $file = $upload_path . $image_data['file_name'];
                                    if (file_exists($file)) {
                                        unlink($file);
                                    }
                                }
                            } 
                            else 
                            {
                                $data['resize_img'] = $upload_path . $image_data['file_name'];
                                
                                $fileName1 = "Profile_image/".$image_data['file_name']; 
                                
                                //$this->handle_success('Image was successfully uploaded to direcoty <strong>' . $upload_path . '</strong> and resized.');
                            }
            
                            /*
                            //load the error and success messages
                            $data['errors'] = $this->error;
                            $data['success'] = $this->success;
                            //load the view along with data
                            $this->load->view('resize', $data);
                            */
                        }
                    }
                }
                
		        $imageData = array(
		                    
                            'kon_profile_pic'=>$fileName,
                            'kon_thumb_pic'=>$fileName1,//$image_data['file_name'],
				);
    		
                $this->db->update('konnect_users',$imageData,array('id'=>$user_id ));
		 
		        $uploaddata = array(
		            'user_id'=>$user_id,
                    'uploaded_image'=> $fileName,
                );
				
                $this->db->insert('upload_image',$uploaddata);

                $this->response([
                    'status' => TRUE,
                    'message' => 'Profile Image Uploaded'
                    //'data' => $data
                ], REST_Controller::HTTP_OK);
                                
	        
		    } 
		    else
			{
       
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
            }

		}
		else
		{
            
                $this->response([
                    'status' => FALSE,
                    'message' => 'Required parameters are not available.'
                ], REST_Controller::HTTP_BAD_REQUEST);
                //$this->response("Required parameters are not available.", REST_Controller::HTTP_BAD_REQUEST);
        }
    } 
     
	
}


/*
public function index_post()
{
    
	$user_id = $this->post('user_id');
		
if(!empty($user_id))
	{
		  if (!empty($_FILES['image']['name']))
		   {    
        
            $imagename=date("d-m-Y")."-".time();
       
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            if($ext ==='gif' || $ext ==='jpg' || $ext ==='png' || $ext ==='PNG' ||$ext ==='jpeg')
            {
            $config = array(
            'upload_path'   => './upload/Profile_image/',
            'allowed_types' => 'gif|jpg|png|jpeg',
            'max_size' => "2048", // Can be set to particular file size , here it is 2 MB(2048 Kb)
            'file_name'     =>$imagename //"criminal_images!".$imagename
            );        
            $this->load->library('upload');
            $this->upload->initialize($config);
                    
            if(!$this->upload->do_upload('image'))
            {
            $error = array('error' => $this->upload->display_errors());
            echo $this->upload->display_errors() ;
            die("image");
            }
            else
            {
            $imageDetailArray = $this->upload->data();
            $fileName = "Profile_image/".$imagename. '.' .$ext; // $imageDetailArray['file_name'];
            }
            }
       
		$imageData = array(
		                    
                            'kon_profile_pic'=>$fileName,
							);
    		
         $this->db->update('konnect_users',$imageData,array('id'=>$user_id ));
		 
		 $uploaddata = array(
		       'user_id'=>$user_id,
               'uploaded_image'=> $fileName,
                );
				
         $this->db->insert('upload_image',$uploaddata);
		  
		 $this->response([
                    'status' => TRUE,
                    'message' => 'Image Uploaded',
					'data' => $imageData
                ], REST_Controller::HTTP_OK);
                
            }
	
		else
			{
        $fileName='';
       
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
		}else{
            
                $this->response([
                    'status' => FALSE,
                    'message' => 'Required parameters are not available.'
                ], REST_Controller::HTTP_BAD_REQUEST);
            //$this->response("Required parameters are not available.", REST_Controller::HTTP_BAD_REQUEST);
        }
    } 
*/
