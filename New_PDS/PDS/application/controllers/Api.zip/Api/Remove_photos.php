<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Remove_photos extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$user_id = $this->post('user_id');
	
        if(!empty($user_id))
        {
			 $remove = array(
    		'kon_profile_pic'=> '',
    		);
    		
         $this->db->update('konnect_users',$remove,array('id'=>$user_id));
	     
           
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
                ], REST_Controller::HTTP_OK);
                
        }
            else{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
           
    }
}
