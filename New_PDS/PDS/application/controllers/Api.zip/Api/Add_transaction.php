<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_transaction extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$service_id = $this->post('service_id');
		$service_name = $this->post('service_name');
		$sender_id = $this->post('sender_id');
		$receiver_id = $this->post('receiver_id');
		$paid_amount = $this->post('paid_amount');
		$start_datetime = $this->post('start_datetime');
		$payment_datetime = $this->post('payment_datetime');
		$status = $this->post('status');
		$device_ip = $this->post('device_ip');
		$lat = $this->post('lat');
		$long = $this->post('long');
		$six_digit_random_number = mt_rand(100000, 999999);
		$trd_id = "KT".date("Ymdhis").$six_digit_random_number;
		//die();
	     
    if(!empty($sender_id))
    {
	    $add_transaction = array(
    		'src_id'=> $service_id,
    		'src_name'=>$service_name,
    		'trx_sender_id'=>$sender_id,
    		'trx_receiver_id'=>$receiver_id,
    		'trx_amount'=>$paid_amount,
    		'trx_transaction_id'=>$trd_id,
    		'trx_start_datetime'=>$start_datetime,
    		'trx_payment_datetime'=>$payment_datetime,
    		'trax_device_ip'=>$device_ip,
    		'usr_lat'=>$lat,
    		'usr_long'=>$long,
    		'trx_status'=>$status
    		);
	
        $this->db->insert('int_payment_transactions',$add_transaction);
		$transaction_last_id =$this->db->insert_id();
		 
	$query = $this->db->query("SELECT src_name as service_name, trx_sender_id as sent_by, trx_receiver_id as received_by, trx_amount as amount, trx_transaction_id as transaction_id, trx_start_datetime as start_date, trx_payment_datetime as payment_date, trx_status as status from int_payment_transactions where tran_id = '".$transaction_last_id."'");
            
            if ($query->num_rows() > 0)
            {
				$transactionData = $query->row_array();
            }
            
	        $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $transactionData
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
