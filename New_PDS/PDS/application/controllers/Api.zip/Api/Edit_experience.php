<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Edit_experience extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$e_id = $this->post('e_id');
		$user_id = $this->post('user_id');
		$user_company_name = $this->post('user_company_name');
        $user_title = $this->post('user_title');
		$user_time_period = $this->post('user_time_period');
		$user_from_date = $this->post('user_from_date');
        $user_to_date = $this->post('user_to_date');
        $user_location = $this->post('user_location');
		$user_description = $this->post('user_description');

	if(!empty($user_company_name))
    {
      $edit_experience = array(
    		'company_name'=>$user_company_name,
    		'title'=>$user_title,
    		'time_period'=>$user_time_period,
    		'from_date'=> $user_from_date,
    		'to_date'=>$user_to_date,
    		'location'=>$user_location,
    		'description'=>$user_description,
    		
    		);
    		
         $this->db->update('user_experience',$edit_experience,array('id'=>$e_id,'user_id'=>$user_id));
	      
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $edit_experience
                ], REST_Controller::HTTP_OK);
                
         }
            else
			{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }   
            
           
    }
}
