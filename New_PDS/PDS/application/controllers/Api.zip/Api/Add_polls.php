<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_polls extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$user_id = $this->post('user_id');
		$user_title = $this->post('user_title');
		$user_choice1 = $this->post('user_choice1');
		$user_choice2 = $this->post('user_choice2');
		$user_choice3 = $this->post('user_choice3');
		$user_choice4 = $this->post('user_choice4');
		$user_correct_choice = $this->post('user_correct_choice');
		$user_image = $this->post('user_image');
        $user_level = $this->post('user_level');
		$user_share = $this->post('user_share');
        $user_tags = $this->post('user_tags');
        $user_language = $this->post('user_language');
		$user_restrict_to = $this->post('user_restrict_to');
        $user_duration = $this->post('user_duration');
		$user_content_type = $this->post('user_content_type');
        $user_pricing = $this->post('user_pricing');
		
		$imagename=date("d-m-Y")."-".time();
       
            $ext = pathinfo($_FILES['user_image']['name'], PATHINFO_EXTENSION);
            if($ext ==='gif' || $ext ==='jpg' || $ext ==='png' || $ext ==='PNG' ||$ext ==='jpeg')
            {
            $config = array(
            'upload_path'   => './upload/Poll_image/',
            'allowed_types' => 'gif|jpg|png|jpeg',
            'max_size' => "2048", // Can be set to particular file size , here it is 2 MB(2048 Kb)
            'file_name'     =>$imagename //"criminal_images!".$imagename
            );        
            $this->load->library('upload');
            $this->upload->initialize($config);
                    
            if(!$this->upload->do_upload('user_image'))
            {
            $error = array('error' => $this->upload->display_errors());
            echo $this->upload->display_errors() ;
            die("user_image");
            }
            else
            {
            $imageDetailArray = $this->upload->data();
            $fileName = "Poll_image/".$imagename. '.' .$ext; // $imageDetailArray['file_name'];
            }
            }
	     
    if(!empty($user_title))
    {
	    $add_poll = array(
    		'user_id'=> $user_id,
    		'kon_choice1'=>$user_choice1,
    		'kon_choice2'=>$user_choice2,
    		'kon_choice3'=>$user_choice3,
    		'kon_choice4'=>$user_choice4,
    		'kon_correct_choice'=>$user_correct_choice,
    		'kon_image'=>$fileName,
    		'kon_title'=>$user_title,
    		'kon_level'=>$user_level,
    		'kon_share'=> $user_share,
    		'kon_tag'=>$user_tags,
    		'kon_language'=>$user_language,
    		'kon_restrict_to'=>$user_restrict_to,
    		'kon_duration'=>$user_duration,
    		'kon_content_type'=>$user_content_type,
    		'kon_pricing'=>$user_pricing,
    		);
	
        $this->db->insert('poll_list',$add_poll);
	      
		$poll_last_id =$this->db->insert_id();
			
            $timeLineData = array(
			      'poll_id'=> $poll_last_id,
			      'user_id'=> $user_id,
    		      'kon_image'=>$fileName,
    		      'kon_title'=>$user_title,
    		      'kon_choice1'=>$user_choice1,
    		      'kon_choice2'=>$user_choice2,
    		      'kon_choice3'=>$user_choice3,
    		      'kon_choice4'=>$user_choice4,
    		      'kon_correct_choice'=>$user_correct_choice,
    		      'kon_level'=>$user_level,
    		      'kon_share'=> $user_share,
    		      'kon_tag'=>$user_tags,
    		      'kon_language'=>$user_language,
    		      'kon_restrict_to'=>$user_restrict_to,
    		      'kon_duration'=>$user_duration,
    		      'kon_content_type'=>$user_content_type,
    		      'kon_pricing'=>$user_pricing,
    		      'kon_post_type'=>'Poll',
    		      'image_category'=>'Poll Image',
			 );
            $this->db->insert('timeLine_posts',$timeLineData);
			
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_poll
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
