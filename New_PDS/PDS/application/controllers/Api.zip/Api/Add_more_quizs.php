<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_more_quizs extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
	    $quiz_id = $this->post('quiz_id');
		$user_id = $this->post('user_id');
		$user_answer1 = $this->post('user_answer1');
		$user_answer2 = $this->post('user_answer2');
		
    if(!empty($user_id))
    {
	    $add_more_answer_quiz = array(
    		'kon_answer3'=>$user_answer1,
    		'kon_answer4'=>$user_answer2,
    		);
	     
		$this->db->update('quiz_list',$add_more_answer_quiz,array('id'=>$quiz_id,'kon_user_id'=>$user_id));
	     
		$add_more_answer_quiz_timeline = array(
    		'kon_choice3'=>$user_answer1,
    		'kon_choice4'=>$user_answer2,
    		);
			
		$this->db->update('timeLine_posts',$add_more_answer_quiz_timeline,array('quiz_id'=>$quiz_id,'user_id'=>$user_id));
	      
	    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $add_more_answer_quiz
                ], REST_Controller::HTTP_OK);
    }
    else
   {
        $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
    }
}
}
