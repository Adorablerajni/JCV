<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Messages_list extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_get()
{
    
        //$chat_id = $this->get('c_id');
        $r_id = $this->get('r_id');
        $s_id = $this->get('s_id');
		
	if(!empty($s_id) && !empty($r_id)) 
		{
		$query = $this->db->query("SELECT chat_msgs.* from chat_msgs where (chat_msgs.sender_id = '".$s_id."' AND chat_msgs.receiver_id = '".$r_id."') OR (chat_msgs.sender_id = '".$r_id."' AND chat_msgs.receiver_id = '".$s_id."') order by creation_date asc");
            
            if ($query->num_rows() > 0)
            {
				$chatData = array();
                $chatData = $query->result_array();
               
			    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $chatData
                ], REST_Controller::HTTP_OK);
            }
            else
			{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
            }
        }
		else
		{
        $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
       }
           
}
}
