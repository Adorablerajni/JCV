<?php

namespace Webkul\CartRule\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Routing\Router;

class CartRuleServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot(Router $router)
    {
        $this->loadMigrationsFrom(__DIR__ . '/../Database/Migrations');

        $this->app->register(EventServiceProvider::class);
    }
}