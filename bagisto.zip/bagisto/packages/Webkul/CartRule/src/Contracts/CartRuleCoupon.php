<?php

namespace Webkul\CartRule\Contracts;

interface CartRuleCoupon
{
}