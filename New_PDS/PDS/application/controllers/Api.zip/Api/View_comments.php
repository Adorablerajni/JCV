<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class View_comments extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_get()
{
        $post_id = $this->get('post_id');
		
	if(!empty($_GET)) 
		{
		$query = $this->db->query("SELECT timeline_post_comments.id as comment_id, timeline_post_comments.comments, timeline_post_comments.commented_by, timeline_post_comments.creation_date, konnect_users.kon_name, konnect_users.kon_profile_pic from timeline_post_comments INNER JOIN konnect_users on (timeline_post_comments.commented_by = konnect_users.id) where timeline_post_comments.timeline_post_id = '".$post_id."' order by timeline_post_comments.id ASC");
            
            if ($query->num_rows() > 0)
            {
				//$userData = array();
                //$userData = $query->result_array();
               
			   $data1['viewcomments'] = $query->result_array();
                $i=0;
                function time_ago( $date )
{
    if( empty( $date ) )
    {
        return "No date provided";
    }

    $periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");

    $lengths = array("60","60","24","7","4.35","12","10");
    
    date_default_timezone_set('Asia/Kolkata'); 
     $now = time(); 
     //$currentDate = date('Y-m-d h:ia', $now); 

     $unix_date = strtotime( $date );

    // check validity of date

    if( empty( $unix_date ) )
    {
        return "Bad date";
    }

    // is it future date or past date

    if( $now > $unix_date )
    {
        $difference = $now - $unix_date;
        $tense = "ago";
    }
    else
    {
        $difference = $unix_date - $now;
        $tense = "from now";
    }

    for( $j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++ )
    {
        $difference /= $lengths[$j];
    }

    $difference = round( $difference );

    if( $difference != 1 )
    {
        $periods[$j].= "s";
    }

    return "$difference $periods[$j] {$tense}";

}
 
  foreach($data1['viewcomments'] as $val)
                {
  
   $nit = date('Y-m-d h:ia', strtotime($val['creation_date'])); 
                     $post_time = time_ago($nit);
 

				$userData[$i] = array(

                								'comment_id'=>$val['comment_id'], 
                								'comments'=>$val['comments'],
                								'commented_by'=>$val['commented_by'],
                								'kon_name'=>$val['kon_name'],
                								'kon_profile_pic'=>$val['kon_profile_pic'],
                								'creation_date'=> $post_time
				
                			);

                  $i++;
                }
               
			   $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $userData
                ], REST_Controller::HTTP_OK);
            }
            else
			{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
            }
        }
		else
		{
        $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
       }
           
}
}
