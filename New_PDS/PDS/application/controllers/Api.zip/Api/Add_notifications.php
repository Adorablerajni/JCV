<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Add_notifications extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$notification_type = $this->post('notification_type');
		$notifications = $this->post('notifications');
		$notifications_for = $this->post('notifications_for');
        $notifications_by = $this->post('notifications_by');
          
            $notificationsData = array(
			      'notification_type'=> $notification_type,
    		      'notifications'=>$notifications,
    		      'notification_for'=>$notifications_for,
    		      'notification_by'=>$notifications_by,
			 );
			 
            $this->db->insert('notification_tbl',$notificationsData);
		   
		   $this->response([
                        'status' => TRUE,
                        'message' => 'Success',
    					'data' => $notificationsData
                    ], REST_Controller::HTTP_OK);
                    
}
       
}
