<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class View_user_transactions extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
public function index_get()
{
        $user_id = $this->get('user_id');
		
	if(!empty($_GET)) 
		{
		$query = $this->db->query("SELECT int_payment_transactions.*, konnect_users.kon_name, konnect_users.kon_thumb_pic from int_payment_transactions INNER JOIN konnect_users on konnect_users.id = int_payment_transactions.trx_receiver_id where trx_sender_id = '".$user_id."' order by tran_id desc");
            
            if ($query->num_rows() > 0)
            {
				
                $userData = $query->result_array();
               
			    $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
					'data' => $userData
                ], REST_Controller::HTTP_OK);
            }
            else
			{
               $this->response([
                    'status' => FALSE,
                    'message' => 'Failed'
                ], REST_Controller::HTTP_OK);
            }
            
}
		else
		{
        $this->response([
        'status' => FALSE,
        'message' => 'Required parameters are not available.'
        ], REST_Controller::HTTP_BAD_REQUEST);
       }
        
           
}
}
