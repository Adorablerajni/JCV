<?php

namespace Webkul\CartRule\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CartRuleCustomerProxy extends ModelProxy
{

}
