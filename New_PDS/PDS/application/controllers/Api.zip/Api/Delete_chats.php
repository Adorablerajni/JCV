<?php
   
require APPPATH . '/libraries/REST_Controller.php';
     
class Delete_chats extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->database();
    }
       
    
public function index_post()
{
		$post_id = $this->post('post_id');
		$comment_id = $this->post('comment_id');
	
        if(!empty($post_id) && !empty($comment_id))
        {
           $query = $this->db->query("SELECT `id` as comment_id, `timeline_post_id`, `comments`, `commented_by` from timeline_post_comments where timeline_post_id = '".$post_id."' AND id = '".$comment_id."'");
            
            if ($query->num_rows() > 0)
            {
				$userData = array();
                $userData = $query->result_array();
                $this->db->where('id', $userData['0']['comment_id']);
            $this->db->delete('timeline_post_comments');
                
            }
           
		   
		   
	     $this->response([
                    'status' => TRUE,
                    'message' => 'Success',
                ], REST_Controller::HTTP_OK);
                
            }
            else{
                
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed!!!'
                ], REST_Controller::HTTP_OK);
            
        }
           
    }
}
